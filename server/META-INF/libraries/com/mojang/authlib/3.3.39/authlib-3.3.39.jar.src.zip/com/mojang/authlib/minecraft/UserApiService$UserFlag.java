/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum UserFlag
/*    */ {
/* 12 */   SERVERS_ALLOWED,
/*    */ 
/*    */ 
/*    */   
/* 16 */   REALMS_ALLOWED,
/*    */ 
/*    */ 
/*    */   
/* 20 */   CHAT_ALLOWED,
/*    */ 
/*    */ 
/*    */   
/* 24 */   TELEMETRY_ENABLED,
/*    */ 
/*    */ 
/*    */   
/* 28 */   PROFANITY_FILTER_ENABLED;
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\UserApiService$UserFlag.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */