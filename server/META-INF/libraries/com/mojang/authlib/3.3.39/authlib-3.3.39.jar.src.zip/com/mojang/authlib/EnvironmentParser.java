/*    */ package com.mojang.authlib;
/*    */ 
/*    */ import com.mojang.authlib.yggdrasil.YggdrasilEnvironment;
/*    */ import java.util.Arrays;
/*    */ import java.util.Optional;
/*    */ import javax.annotation.Nullable;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class EnvironmentParser
/*    */ {
/*    */   @Nullable
/*    */   private static String environmentOverride;
/*    */   private static final String PROP_PREFIX = "minecraft.api.";
/*    */   
/*    */   public static void setEnvironmentOverride(String override) {
/* 17 */     environmentOverride = override;
/*    */   }
/*    */ 
/*    */   
/* 21 */   private static final Logger LOGGER = LoggerFactory.getLogger(EnvironmentParser.class);
/*    */   
/*    */   public static final String PROP_ENV = "minecraft.api.env";
/*    */   public static final String PROP_AUTH_HOST = "minecraft.api.auth.host";
/*    */   public static final String PROP_ACCOUNT_HOST = "minecraft.api.account.host";
/*    */   public static final String PROP_SESSION_HOST = "minecraft.api.session.host";
/*    */   public static final String PROP_SERVICES_HOST = "minecraft.api.services.host";
/*    */   
/*    */   public static Optional<Environment> getEnvironmentFromProperties() {
/* 30 */     String envName = (environmentOverride != null) ? environmentOverride : System.getProperty("minecraft.api.env");
/* 31 */     Optional<Environment> env = YggdrasilEnvironment.fromString(envName);
/* 32 */     return env.isPresent() ? env : fromHostNames();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static Optional<Environment> fromHostNames() {
/* 38 */     String auth = System.getProperty("minecraft.api.auth.host");
/* 39 */     String account = System.getProperty("minecraft.api.account.host");
/* 40 */     String session = System.getProperty("minecraft.api.session.host");
/* 41 */     String services = System.getProperty("minecraft.api.services.host");
/*    */     
/* 43 */     if (auth != null && account != null && session != null)
/* 44 */       return Optional.of(Environment.create(auth, account, session, services, "properties")); 
/* 45 */     if (auth != null || account != null || session != null) {
/* 46 */       LOGGER.info("Ignoring hosts properties. All need to be set: " + 
/* 47 */           Arrays.<String>asList(new String[] { "minecraft.api.auth.host", "minecraft.api.account.host", "minecraft.api.session.host" }));
/*    */     }
/* 49 */     return Optional.empty();
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\EnvironmentParser.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */