/*     */ package com.mojang.authlib.yggdrasil;
/*     */ import com.google.common.cache.CacheBuilder;
/*     */ import com.google.common.cache.CacheLoader;
/*     */ import com.google.common.cache.LoadingCache;
/*     */ import com.google.common.collect.Iterables;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.mojang.authlib.AuthenticationService;
/*     */ import com.mojang.authlib.Environment;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.HttpAuthenticationService;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
/*     */ import com.mojang.authlib.minecraft.HttpMinecraftSessionService;
/*     */ import com.mojang.authlib.minecraft.InsecureTextureException;
/*     */ import com.mojang.authlib.minecraft.MinecraftProfileTexture;
/*     */ import com.mojang.authlib.properties.Property;
/*     */ import com.mojang.authlib.yggdrasil.request.JoinMinecraftServerRequest;
/*     */ import com.mojang.authlib.yggdrasil.response.HasJoinedMinecraftServerResponse;
/*     */ import com.mojang.authlib.yggdrasil.response.MinecraftProfilePropertiesResponse;
/*     */ import com.mojang.authlib.yggdrasil.response.MinecraftTexturesPayload;
/*     */ import com.mojang.authlib.yggdrasil.response.Response;
/*     */ import com.mojang.util.UUIDTypeAdapter;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.PublicKey;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.Base64;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class YggdrasilMinecraftSessionService extends HttpMinecraftSessionService {
/*  44 */   private static final String[] ALLOWED_DOMAINS = new String[] { ".minecraft.net", ".mojang.com" };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private static final String[] BLOCKED_DOMAINS = new String[] { "bugs.mojang.com", "education.minecraft.net", "feedback.minecraft.net" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private static final Logger LOGGER = LoggerFactory.getLogger(YggdrasilMinecraftSessionService.class);
/*     */   
/*     */   private final String baseUrl;
/*     */   private final URL joinUrl;
/*     */   private final URL checkUrl;
/*     */   private final PublicKey publicKey;
/*  61 */   private final Gson gson = (new GsonBuilder()).registerTypeAdapter(UUID.class, new UUIDTypeAdapter()).create();
/*     */   
/*  63 */   private final LoadingCache<GameProfile, GameProfile> insecureProfiles = CacheBuilder.newBuilder()
/*  64 */     .expireAfterWrite(6L, TimeUnit.HOURS)
/*  65 */     .build(new CacheLoader<GameProfile, GameProfile>()
/*     */       {
/*     */         public GameProfile load(GameProfile key) {
/*  68 */           return YggdrasilMinecraftSessionService.this.fillGameProfile(key, false);
/*     */         }
/*     */       });
/*     */   
/*     */   protected YggdrasilMinecraftSessionService(YggdrasilAuthenticationService service, Environment env) {
/*  73 */     super(service);
/*     */     
/*  75 */     this.baseUrl = env.getSessionHost() + "/session/minecraft/";
/*     */     
/*  77 */     this.joinUrl = HttpAuthenticationService.constantURL(this.baseUrl + "join");
/*  78 */     this.checkUrl = HttpAuthenticationService.constantURL(this.baseUrl + "hasJoined");
/*     */     
/*     */     try {
/*  81 */       X509EncodedKeySpec spec = new X509EncodedKeySpec(IOUtils.toByteArray(YggdrasilMinecraftSessionService.class.getResourceAsStream("/yggdrasil_session_pubkey.der")));
/*  82 */       KeyFactory keyFactory = KeyFactory.getInstance("RSA");
/*  83 */       this.publicKey = keyFactory.generatePublic(spec);
/*  84 */     } catch (Exception ignored) {
/*  85 */       throw new Error("Missing/invalid yggdrasil public key!");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void joinServer(GameProfile profile, String authenticationToken, String serverId) throws AuthenticationException {
/*  91 */     JoinMinecraftServerRequest request = new JoinMinecraftServerRequest();
/*  92 */     request.accessToken = authenticationToken;
/*  93 */     request.selectedProfile = profile.getId();
/*  94 */     request.serverId = serverId;
/*     */     
/*  96 */     getAuthenticationService().makeRequest(this.joinUrl, request, Response.class);
/*     */   }
/*     */ 
/*     */   
/*     */   public GameProfile hasJoinedServer(GameProfile user, String serverId, InetAddress address) throws AuthenticationUnavailableException {
/* 101 */     Map<String, Object> arguments = new HashMap<>();
/*     */     
/* 103 */     arguments.put("username", user.getName());
/* 104 */     arguments.put("serverId", serverId);
/*     */     
/* 106 */     if (address != null) {
/* 107 */       arguments.put("ip", address.getHostAddress());
/*     */     }
/*     */     
/* 110 */     URL url = HttpAuthenticationService.concatenateURL(this.checkUrl, HttpAuthenticationService.buildQuery(arguments));
/*     */     
/*     */     try {
/* 113 */       HasJoinedMinecraftServerResponse response = getAuthenticationService().<HasJoinedMinecraftServerResponse>makeRequest(url, null, HasJoinedMinecraftServerResponse.class);
/*     */       
/* 115 */       if (response != null && response.getId() != null) {
/* 116 */         GameProfile result = new GameProfile(response.getId(), user.getName());
/*     */         
/* 118 */         if (response.getProperties() != null) {
/* 119 */           result.getProperties().putAll((Multimap)response.getProperties());
/*     */         }
/*     */         
/* 122 */         return result;
/*     */       } 
/* 124 */       return null;
/*     */     }
/* 126 */     catch (AuthenticationUnavailableException e) {
/* 127 */       throw e;
/* 128 */     } catch (AuthenticationException ignored) {
/* 129 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> getTextures(GameProfile profile, boolean requireSecure) {
/*     */     MinecraftTexturesPayload result;
/* 135 */     Property textureProperty = (Property)Iterables.getFirst(profile.getProperties().get("textures"), null);
/*     */     
/* 137 */     if (textureProperty == null) {
/* 138 */       return new HashMap<>();
/*     */     }
/*     */     
/* 141 */     if (requireSecure) {
/* 142 */       if (!textureProperty.hasSignature()) {
/* 143 */         LOGGER.error("Signature is missing from textures payload");
/* 144 */         throw new InsecureTextureException("Signature is missing from textures payload");
/*     */       } 
/*     */       
/* 147 */       if (!textureProperty.isSignatureValid(this.publicKey)) {
/* 148 */         LOGGER.error("Textures payload has been tampered with (signature invalid)");
/* 149 */         throw new InsecureTextureException("Textures payload has been tampered with (signature invalid)");
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 155 */       String json = new String(Base64.getDecoder().decode(textureProperty.getValue()), StandardCharsets.UTF_8);
/* 156 */       result = (MinecraftTexturesPayload)this.gson.fromJson(json, MinecraftTexturesPayload.class);
/* 157 */     } catch (JsonParseException e) {
/* 158 */       LOGGER.error("Could not decode textures payload", (Throwable)e);
/* 159 */       return new HashMap<>();
/*     */     } 
/*     */     
/* 162 */     if (result == null || result.getTextures() == null) {
/* 163 */       return new HashMap<>();
/*     */     }
/*     */     
/* 166 */     for (Map.Entry<MinecraftProfileTexture.Type, MinecraftProfileTexture> entry : (Iterable<Map.Entry<MinecraftProfileTexture.Type, MinecraftProfileTexture>>)result.getTextures().entrySet()) {
/* 167 */       String url = ((MinecraftProfileTexture)entry.getValue()).getUrl();
/* 168 */       if (!isAllowedTextureDomain(url)) {
/* 169 */         LOGGER.error("Textures payload contains blocked domain: {}", url);
/* 170 */         return new HashMap<>();
/*     */       } 
/*     */     } 
/*     */     
/* 174 */     return result.getTextures();
/*     */   }
/*     */ 
/*     */   
/*     */   public GameProfile fillProfileProperties(GameProfile profile, boolean requireSecure) {
/* 179 */     if (profile.getId() == null) {
/* 180 */       return profile;
/*     */     }
/*     */     
/* 183 */     if (!requireSecure) {
/* 184 */       return (GameProfile)this.insecureProfiles.getUnchecked(profile);
/*     */     }
/*     */     
/* 187 */     return fillGameProfile(profile, true);
/*     */   }
/*     */   
/*     */   protected GameProfile fillGameProfile(GameProfile profile, boolean requireSecure) {
/*     */     try {
/* 192 */       URL url = HttpAuthenticationService.constantURL(this.baseUrl + "profile/" + this.baseUrl);
/* 193 */       url = HttpAuthenticationService.concatenateURL(url, "unsigned=" + (!requireSecure ? 1 : 0));
/* 194 */       MinecraftProfilePropertiesResponse response = getAuthenticationService().<MinecraftProfilePropertiesResponse>makeRequest(url, null, MinecraftProfilePropertiesResponse.class);
/*     */       
/* 196 */       if (response == null) {
/* 197 */         LOGGER.debug("Couldn't fetch profile properties for " + profile + " as the profile does not exist");
/* 198 */         return profile;
/*     */       } 
/* 200 */       GameProfile result = new GameProfile(response.getId(), response.getName());
/* 201 */       result.getProperties().putAll((Multimap)response.getProperties());
/* 202 */       profile.getProperties().putAll((Multimap)response.getProperties());
/* 203 */       LOGGER.debug("Successfully fetched profile properties for " + profile);
/* 204 */       return result;
/*     */     }
/* 206 */     catch (AuthenticationException e) {
/* 207 */       LOGGER.warn("Couldn't look up profile properties for " + profile, (Throwable)e);
/* 208 */       return profile;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public YggdrasilAuthenticationService getAuthenticationService() {
/* 214 */     return (YggdrasilAuthenticationService)super.getAuthenticationService();
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean isAllowedTextureDomain(String url) {
/*     */     URI uri;
/*     */     try {
/* 221 */       uri = new URI(url);
/* 222 */     } catch (URISyntaxException ignored) {
/* 223 */       throw new IllegalArgumentException("Invalid URL '" + url + "'");
/*     */     } 
/*     */     
/* 226 */     String domain = uri.getHost();
/* 227 */     return (isDomainOnList(domain, ALLOWED_DOMAINS) && !isDomainOnList(domain, BLOCKED_DOMAINS));
/*     */   }
/*     */   
/*     */   private static boolean isDomainOnList(String domain, String[] list) {
/* 231 */     for (String entry : list) {
/* 232 */       if (domain.endsWith(entry)) {
/* 233 */         return true;
/*     */       }
/*     */     } 
/* 236 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrasilMinecraftSessionService.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */