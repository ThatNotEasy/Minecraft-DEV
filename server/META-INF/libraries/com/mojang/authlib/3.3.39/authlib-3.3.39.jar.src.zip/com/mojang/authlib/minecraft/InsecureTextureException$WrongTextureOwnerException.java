/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WrongTextureOwnerException
/*    */   extends InsecureTextureException
/*    */ {
/*    */   private final GameProfile expected;
/*    */   private final UUID resultId;
/*    */   private final String resultName;
/*    */   
/*    */   public WrongTextureOwnerException(GameProfile expected, UUID resultId, String resultName) {
/* 31 */     super("Decrypted textures payload was for another user (expected " + expected.getId() + "/" + expected.getName() + " but was for " + resultId + "/" + resultName + ")");
/* 32 */     this.expected = expected;
/* 33 */     this.resultId = resultId;
/* 34 */     this.resultName = resultName;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\InsecureTextureException$WrongTextureOwnerException.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */