/*    */ package com.mojang.authlib.yggdrasil;
/*    */ import com.google.common.annotations.VisibleForTesting;
/*    */ import com.google.common.collect.ImmutableList;
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.mojang.authlib.Environment;
/*    */ import com.mojang.authlib.HttpAuthenticationService;
/*    */ import com.mojang.authlib.exceptions.MinecraftClientException;
/*    */ import com.mojang.authlib.minecraft.TelemetryEvent;
/*    */ import com.mojang.authlib.minecraft.TelemetryPropertyContainer;
/*    */ import com.mojang.authlib.minecraft.client.MinecraftClient;
/*    */ import com.mojang.authlib.yggdrasil.request.TelemetryEventsRequest;
/*    */ import com.mojang.authlib.yggdrasil.response.Response;
/*    */ import java.net.URL;
/*    */ import java.time.Instant;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.function.Consumer;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class YggdrassilTelemetrySession implements TelemetrySession {
/* 24 */   private static final Logger LOGGER = LoggerFactory.getLogger(YggdrassilTelemetrySession.class);
/*    */   
/*    */   private static final String SOURCE = "minecraft.java";
/*    */   
/*    */   private final MinecraftClient minecraftClient;
/*    */   
/*    */   private final URL routeEvents;
/*    */   private final Executor ioExecutor;
/* 32 */   private final JsonObject globalProperties = new JsonObject(); private Consumer<TelemetryPropertyContainer> eventSetupFunction = event -> {
/*    */     
/*    */     };
/*    */   @VisibleForTesting
/*    */   YggdrassilTelemetrySession(MinecraftClient minecraftClient, Environment environment, Executor ioExecutor) {
/* 37 */     this.minecraftClient = minecraftClient;
/* 38 */     this.routeEvents = HttpAuthenticationService.constantURL(environment.getServicesHost() + "/events");
/* 39 */     this.ioExecutor = ioExecutor;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 44 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public TelemetryEvent createNewEvent(String type) {
/* 49 */     return new YggdrassilTelemetryEvent(this, type);
/*    */   }
/*    */ 
/*    */   
/*    */   public TelemetryPropertyContainer globalProperties() {
/* 54 */     return TelemetryPropertyContainer.forJsonObject(this.globalProperties);
/*    */   }
/*    */ 
/*    */   
/*    */   public void eventSetupFunction(Consumer<TelemetryPropertyContainer> eventSetupFunction) {
/* 59 */     this.eventSetupFunction = eventSetupFunction;
/*    */   }
/*    */   
/*    */   void sendEvent(String type, JsonObject data) {
/* 63 */     Instant sendTime = Instant.now();
/* 64 */     this.globalProperties.entrySet().forEach(e -> data.add((String)e.getKey(), (JsonElement)e.getValue()));
/* 65 */     this.eventSetupFunction.accept(TelemetryPropertyContainer.forJsonObject(data));
/* 66 */     TelemetryEventsRequest.Event request = new TelemetryEventsRequest.Event("minecraft.java", type, sendTime, data);
/*    */     
/* 68 */     this.ioExecutor.execute(() -> {
/*    */           try {
/*    */             TelemetryEventsRequest envelope = new TelemetryEventsRequest((List)ImmutableList.of(request));
/*    */             this.minecraftClient.post(this.routeEvents, envelope, Response.class);
/* 72 */           } catch (MinecraftClientException e) {
/*    */             LOGGER.debug("Failed to send telemetry event {}", request.name, e);
/*    */           } 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrassilTelemetrySession.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */