/*    */ package com.mojang.authlib.yggdrasil;
/*    */ 
/*    */ public class ProfileIncompleteException
/*    */   extends RuntimeException {
/*    */   public ProfileIncompleteException() {}
/*    */   
/*    */   public ProfileIncompleteException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public ProfileIncompleteException(String message, Throwable cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public ProfileIncompleteException(Throwable cause) {
/* 16 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\ProfileIncompleteException.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */