/*    */ package com.mojang.authlib.yggdrasil.request;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ 
/*    */ public class RefreshRequest {
/*    */   private String clientToken;
/*    */   private String accessToken;
/*    */   private GameProfile selectedProfile;
/*    */   private boolean requestUser = true;
/*    */   
/*    */   public RefreshRequest(String accessToken, String clientToken) {
/* 12 */     this(accessToken, clientToken, null);
/*    */   }
/*    */   
/*    */   public RefreshRequest(String accessToken, String clientToken, GameProfile profile) {
/* 16 */     this.clientToken = clientToken;
/* 17 */     this.accessToken = accessToken;
/* 18 */     this.selectedProfile = profile;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\request\RefreshRequest.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */