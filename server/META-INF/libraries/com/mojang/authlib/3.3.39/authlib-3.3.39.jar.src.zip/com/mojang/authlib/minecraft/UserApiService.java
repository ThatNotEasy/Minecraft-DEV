/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.Executor;
/*    */ 
/*    */ 
/*    */ public interface UserApiService
/*    */ {
/*    */   public enum UserFlag
/*    */   {
/* 12 */     SERVERS_ALLOWED,
/*    */ 
/*    */ 
/*    */     
/* 16 */     REALMS_ALLOWED,
/*    */ 
/*    */ 
/*    */     
/* 20 */     CHAT_ALLOWED,
/*    */ 
/*    */ 
/*    */     
/* 24 */     TELEMETRY_ENABLED,
/*    */ 
/*    */ 
/*    */     
/* 28 */     PROFANITY_FILTER_ENABLED; }
/*    */   public static final class UserProperties extends Record { private final Set<UserApiService.UserFlag> flags;
/*    */     
/* 31 */     public UserProperties(Set<UserApiService.UserFlag> flags) { this.flags = flags; } public final String toString() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> toString : (Lcom/mojang/authlib/minecraft/UserApiService$UserProperties;)Ljava/lang/String;
/*    */       //   6: areturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #31	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/* 31 */       //   0	7	0	this	Lcom/mojang/authlib/minecraft/UserApiService$UserProperties; } public Set<UserApiService.UserFlag> flags() { return this.flags; }
/*    */     public final int hashCode() { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: <illegal opcode> hashCode : (Lcom/mojang/authlib/minecraft/UserApiService$UserProperties;)I
/*    */       //   6: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #31	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	7	0	this	Lcom/mojang/authlib/minecraft/UserApiService$UserProperties; }
/*    */     public final boolean equals(Object o) { // Byte code:
/*    */       //   0: aload_0
/*    */       //   1: aload_1
/*    */       //   2: <illegal opcode> equals : (Lcom/mojang/authlib/minecraft/UserApiService$UserProperties;Ljava/lang/Object;)Z
/*    */       //   7: ireturn
/*    */       // Line number table:
/*    */       //   Java source line number -> byte code offset
/*    */       //   #31	-> 0
/*    */       // Local variable table:
/*    */       //   start	length	slot	name	descriptor
/*    */       //   0	8	0	this	Lcom/mojang/authlib/minecraft/UserApiService$UserProperties;
/* 33 */       //   0	8	1	o	Ljava/lang/Object; } public boolean flag(UserApiService.UserFlag flag) { return this.flags.contains(flag); }
/*    */      }
/*    */ 
/*    */   
/* 37 */   public static final UserProperties OFFLINE_PROPERTIES = new UserProperties(Set.of(UserFlag.CHAT_ALLOWED, UserFlag.REALMS_ALLOWED, UserFlag.SERVERS_ALLOWED));
/*    */   
/* 39 */   public static final UserApiService OFFLINE = new UserApiService()
/*    */     {
/*    */       public UserApiService.UserProperties properties() {
/* 42 */         return OFFLINE_PROPERTIES;
/*    */       }
/*    */ 
/*    */       
/*    */       public boolean isBlockedPlayer(UUID playerID) {
/* 47 */         return false;
/*    */       }
/*    */ 
/*    */ 
/*    */       
/*    */       public void refreshBlockList() {}
/*    */ 
/*    */       
/*    */       public TelemetrySession newTelemetrySession(Executor executor) {
/* 56 */         return TelemetrySession.DISABLED;
/*    */       }
/*    */     };
/*    */   
/*    */   UserProperties properties();
/*    */   
/*    */   boolean isBlockedPlayer(UUID paramUUID);
/*    */   
/*    */   void refreshBlockList();
/*    */   
/*    */   TelemetrySession newTelemetrySession(Executor paramExecutor);
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\UserApiService.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */