/*    */ package com.mojang.authlib.yggdrasil.response;
/*    */ 
/*    */ import com.mojang.authlib.properties.PropertyMap;
/*    */ 
/*    */ public class User {
/*    */   private String id;
/*    */   private PropertyMap properties;
/*    */   
/*    */   public String getId() {
/* 10 */     return this.id;
/*    */   }
/*    */   
/*    */   public PropertyMap getProperties() {
/* 14 */     return this.properties;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\response\User.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */