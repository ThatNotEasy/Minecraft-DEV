/*    */ package com.mojang.authlib.exceptions;
/*    */ 
/*    */ import com.mojang.authlib.yggdrasil.response.ErrorResponse;
/*    */ import java.util.Optional;
/*    */ import java.util.StringJoiner;
/*    */ import javax.annotation.Nullable;
/*    */ import org.apache.commons.lang3.StringUtils;
/*    */ 
/*    */ public class MinecraftClientHttpException
/*    */   extends MinecraftClientException {
/*    */   public static final int UNAUTHORIZED = 401;
/*    */   public static final int FORBIDDEN = 403;
/*    */   private final int status;
/*    */   @Nullable
/*    */   private final ErrorResponse response;
/*    */   
/*    */   public MinecraftClientHttpException(int status) {
/* 18 */     super(MinecraftClientException.ErrorType.HTTP_ERROR, getErrorMessage(status, (ErrorResponse)null));
/* 19 */     this.status = status;
/* 20 */     this.response = null;
/*    */   }
/*    */   
/*    */   public MinecraftClientHttpException(int status, ErrorResponse response) {
/* 24 */     super(MinecraftClientException.ErrorType.HTTP_ERROR, getErrorMessage(status, response));
/* 25 */     this.status = status;
/* 26 */     this.response = response;
/*    */   }
/*    */   
/*    */   public int getStatus() {
/* 30 */     return this.status;
/*    */   }
/*    */   
/*    */   public Optional<ErrorResponse> getResponse() {
/* 34 */     return Optional.ofNullable(this.response);
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 39 */     return (new StringJoiner(", ", MinecraftClientHttpException.class.getSimpleName() + "[", "]"))
/* 40 */       .add("type=" + this.type)
/* 41 */       .add("status=" + this.status)
/* 42 */       .add("response=" + this.response)
/* 43 */       .toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AuthenticationException toAuthenticationException() {
/* 51 */     if (hasError("InsufficientPrivilegesException") || this.status == 403) {
/* 52 */       return new InsufficientPrivilegesException(getMessage(), this);
/*    */     }
/*    */     
/* 55 */     if (this.status == 401) {
/* 56 */       return new InvalidCredentialsException(getMessage(), this);
/*    */     }
/*    */     
/* 59 */     if (this.status >= 500) {
/* 60 */       return new AuthenticationUnavailableException(getMessage(), this);
/*    */     }
/*    */     
/* 63 */     return new AuthenticationException(getMessage(), this);
/*    */   }
/*    */   
/*    */   private Optional<String> getError() {
/* 67 */     return getResponse()
/* 68 */       .<String>map(ErrorResponse::getError)
/* 69 */       .filter(StringUtils::isNotEmpty);
/*    */   }
/*    */   
/*    */   private static String getErrorMessage(int status, ErrorResponse response) {
/*    */     String errorMessage;
/* 74 */     if (response != null) {
/* 75 */       if (StringUtils.isNotEmpty(response.getErrorMessage())) {
/* 76 */         errorMessage = response.getErrorMessage();
/* 77 */       } else if (StringUtils.isNotEmpty(response.getError())) {
/* 78 */         errorMessage = response.getError();
/*    */       } else {
/* 80 */         errorMessage = "Status: " + status;
/*    */       } 
/*    */     } else {
/* 83 */       errorMessage = "Status: " + status;
/*    */     } 
/* 85 */     return errorMessage;
/*    */   }
/*    */   
/*    */   private boolean hasError(String error) {
/* 89 */     return getError()
/* 90 */       .filter(value -> value.equalsIgnoreCase(error))
/* 91 */       .isPresent();
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\exceptions\MinecraftClientHttpException.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */