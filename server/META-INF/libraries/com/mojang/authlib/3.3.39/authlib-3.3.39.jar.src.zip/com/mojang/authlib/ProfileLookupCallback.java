package com.mojang.authlib;

public interface ProfileLookupCallback {
  void onProfileLookupSucceeded(GameProfile paramGameProfile);
  
  void onProfileLookupFailed(GameProfile paramGameProfile, Exception paramException);
}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\ProfileLookupCallback.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */