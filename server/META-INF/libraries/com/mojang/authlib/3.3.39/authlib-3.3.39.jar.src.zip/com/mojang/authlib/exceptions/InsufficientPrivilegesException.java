/*    */ package com.mojang.authlib.exceptions;
/*    */ 
/*    */ public class InsufficientPrivilegesException
/*    */   extends AuthenticationException {
/*    */   public InsufficientPrivilegesException() {}
/*    */   
/*    */   public InsufficientPrivilegesException(String message) {
/*  8 */     super(message);
/*    */   }
/*    */   
/*    */   public InsufficientPrivilegesException(String message, Throwable cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */   
/*    */   public InsufficientPrivilegesException(Throwable cause) {
/* 16 */     super(cause);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\exceptions\InsufficientPrivilegesException.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */