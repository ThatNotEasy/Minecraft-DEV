/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import java.util.concurrent.Executor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements UserApiService
/*    */ {
/*    */   public UserApiService.UserProperties properties() {
/* 42 */     return OFFLINE_PROPERTIES;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isBlockedPlayer(UUID playerID) {
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void refreshBlockList() {}
/*    */ 
/*    */   
/*    */   public TelemetrySession newTelemetrySession(Executor executor) {
/* 56 */     return TelemetrySession.DISABLED;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\UserApiService$1.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */