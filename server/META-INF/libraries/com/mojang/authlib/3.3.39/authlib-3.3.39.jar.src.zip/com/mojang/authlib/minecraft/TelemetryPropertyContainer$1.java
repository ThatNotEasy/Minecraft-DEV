/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonNull;
/*    */ import com.google.gson.JsonObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements TelemetryPropertyContainer
/*    */ {
/*    */   public void addProperty(String id, String value) {
/* 19 */     object.addProperty(id, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addProperty(String id, int value) {
/* 24 */     object.addProperty(id, Integer.valueOf(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addProperty(String id, boolean value) {
/* 29 */     object.addProperty(id, Boolean.valueOf(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addNullProperty(String id) {
/* 34 */     object.add(id, (JsonElement)JsonNull.INSTANCE);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\TelemetryPropertyContainer$1.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */