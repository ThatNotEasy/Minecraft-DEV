/*    */ package com.mojang.authlib.minecraft.client;
/*    */ 
/*    */ import com.google.gson.Gson;
/*    */ import com.google.gson.GsonBuilder;
/*    */ import com.google.gson.JsonParseException;
/*    */ import com.mojang.authlib.exceptions.MinecraftClientException;
/*    */ import com.mojang.util.UUIDTypeAdapter;
/*    */ import java.util.Objects;
/*    */ import java.util.UUID;
/*    */ 
/*    */ 
/*    */ public class ObjectMapper
/*    */ {
/*    */   private final Gson gson;
/*    */   
/*    */   public ObjectMapper(Gson gson) {
/* 17 */     this.gson = Objects.<Gson>requireNonNull(gson);
/*    */   }
/*    */   
/*    */   public <T> T readValue(String value, Class<T> type) {
/*    */     try {
/* 22 */       return (T)this.gson.fromJson(value, type);
/* 23 */     } catch (JsonParseException e) {
/* 24 */       throw new MinecraftClientException(MinecraftClientException.ErrorType.JSON_ERROR, "Failed to read value " + value, e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public String writeValueAsString(Object entity) {
/*    */     try {
/* 30 */       return this.gson.toJson(entity);
/* 31 */     } catch (RuntimeException e) {
/* 32 */       throw new MinecraftClientException(MinecraftClientException.ErrorType.JSON_ERROR, "Failed to write value", e);
/*    */     } 
/*    */   }
/*    */   
/*    */   public static ObjectMapper create() {
/* 37 */     return new ObjectMapper((new GsonBuilder()).registerTypeAdapter(UUID.class, new UUIDTypeAdapter()).create());
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\client\ObjectMapper.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */