/*     */ package com.mojang.authlib.minecraft.client;
/*     */ 
/*     */ import com.mojang.authlib.exceptions.MinecraftClientException;
/*     */ import com.mojang.authlib.exceptions.MinecraftClientHttpException;
/*     */ import com.mojang.authlib.yggdrasil.response.ErrorResponse;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.lang3.Validate;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MinecraftClient
/*     */ {
/*  29 */   private static final Logger LOGGER = LoggerFactory.getLogger(MinecraftClient.class);
/*     */   
/*     */   public static final int CONNECT_TIMEOUT_MS = 5000;
/*     */   public static final int READ_TIMEOUT_MS = 5000;
/*     */   private final String accessToken;
/*     */   private final Proxy proxy;
/*  35 */   private final ObjectMapper objectMapper = ObjectMapper.create();
/*     */   
/*     */   public MinecraftClient(String accessToken, Proxy proxy) {
/*  38 */     this.accessToken = (String)Validate.notNull(accessToken);
/*  39 */     this.proxy = (Proxy)Validate.notNull(proxy);
/*     */   }
/*     */   
/*     */   public <T> T get(URL url, Class<T> responseClass) {
/*  43 */     Validate.notNull(url);
/*  44 */     Validate.notNull(responseClass);
/*  45 */     HttpURLConnection connection = createUrlConnection(url);
/*  46 */     connection.setRequestProperty("Authorization", "Bearer " + this.accessToken);
/*     */     
/*  48 */     return readInputStream(url, responseClass, connection);
/*     */   }
/*     */   
/*     */   public <T> T post(URL url, Object body, Class<T> responseClass) {
/*  52 */     Validate.notNull(url);
/*  53 */     Validate.notNull(body);
/*  54 */     Validate.notNull(responseClass);
/*  55 */     String bodyAsJson = this.objectMapper.writeValueAsString(body);
/*  56 */     byte[] postAsBytes = bodyAsJson.getBytes(StandardCharsets.UTF_8);
/*  57 */     HttpURLConnection connection = postInternal(url, postAsBytes);
/*  58 */     return readInputStream(url, responseClass, connection);
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T readInputStream(URL url, Class<T> clazz, HttpURLConnection connection) {
/*  63 */     InputStream inputStream = null;
/*     */     try {
/*  65 */       int status = connection.getResponseCode();
/*     */ 
/*     */       
/*  68 */       if (status < 400) {
/*  69 */         inputStream = connection.getInputStream();
/*  70 */         String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
/*  71 */         return (T)this.objectMapper.readValue(result, (Class)clazz);
/*     */       } 
/*  73 */       inputStream = connection.getErrorStream();
/*     */       
/*  75 */       if (inputStream != null) {
/*  76 */         String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
/*  77 */         ErrorResponse errorResponse = this.objectMapper.<ErrorResponse>readValue(result, ErrorResponse.class);
/*  78 */         throw new MinecraftClientHttpException(status, errorResponse);
/*     */       } 
/*  80 */       throw new MinecraftClientHttpException(status);
/*     */     
/*     */     }
/*  83 */     catch (IOException e) {
/*     */       
/*  85 */       throw new MinecraftClientException(MinecraftClientException.ErrorType.SERVICE_UNAVAILABLE, "Failed to read from " + url + " due to " + e
/*  86 */           .getMessage(), e);
/*     */     } finally {
/*  88 */       IOUtils.closeQuietly(inputStream);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private HttpURLConnection postInternal(URL url, byte[] postAsBytes) {
/*  94 */     HttpURLConnection connection = createUrlConnection(url);
/*  95 */     OutputStream outputStream = null;
/*     */     try {
/*  97 */       connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
/*  98 */       connection.setRequestProperty("Content-Length", "" + postAsBytes.length);
/*  99 */       connection.setRequestProperty("Authorization", "Bearer " + this.accessToken);
/* 100 */       connection.setRequestMethod("POST");
/* 101 */       connection.setDoOutput(true);
/* 102 */       outputStream = connection.getOutputStream();
/* 103 */       IOUtils.write(postAsBytes, outputStream);
/* 104 */     } catch (IOException io) {
/* 105 */       throw new MinecraftClientException(MinecraftClientException.ErrorType.SERVICE_UNAVAILABLE, "Failed to POST " + url, io);
/*     */     } finally {
/* 107 */       IOUtils.closeQuietly(outputStream);
/*     */     } 
/* 109 */     return connection;
/*     */   }
/*     */ 
/*     */   
/*     */   private HttpURLConnection createUrlConnection(URL url) {
/*     */     try {
/* 115 */       LOGGER.debug("Connecting to {}", url);
/* 116 */       HttpURLConnection connection = (HttpURLConnection)url.openConnection(this.proxy);
/* 117 */       connection.setConnectTimeout(5000);
/* 118 */       connection.setReadTimeout(5000);
/* 119 */       connection.setUseCaches(false);
/* 120 */       return connection;
/* 121 */     } catch (IOException io) {
/* 122 */       throw new MinecraftClientException(MinecraftClientException.ErrorType.SERVICE_UNAVAILABLE, "Failed connecting to " + url, io);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\client\MinecraftClient.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */