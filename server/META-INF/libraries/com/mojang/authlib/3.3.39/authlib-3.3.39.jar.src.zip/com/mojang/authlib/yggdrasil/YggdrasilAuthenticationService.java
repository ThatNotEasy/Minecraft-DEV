/*     */ package com.mojang.authlib.yggdrasil;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.GsonBuilder;
/*     */ import com.google.gson.JsonDeserializationContext;
/*     */ import com.google.gson.JsonDeserializer;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParseException;
/*     */ import com.google.gson.JsonSerializationContext;
/*     */ import com.google.gson.JsonSerializer;
/*     */ import com.mojang.authlib.Agent;
/*     */ import com.mojang.authlib.Environment;
/*     */ import com.mojang.authlib.EnvironmentParser;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.GameProfileRepository;
/*     */ import com.mojang.authlib.HttpAuthenticationService;
/*     */ import com.mojang.authlib.UserAuthentication;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
/*     */ import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
/*     */ import com.mojang.authlib.exceptions.InvalidCredentialsException;
/*     */ import com.mojang.authlib.exceptions.UserMigratedException;
/*     */ import com.mojang.authlib.minecraft.MinecraftSessionService;
/*     */ import com.mojang.authlib.minecraft.UserApiService;
/*     */ import com.mojang.authlib.properties.PropertyMap;
/*     */ import com.mojang.authlib.yggdrasil.response.ProfileSearchResultsResponse;
/*     */ import com.mojang.authlib.yggdrasil.response.Response;
/*     */ import com.mojang.util.UUIDTypeAdapter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Type;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class YggdrasilAuthenticationService
/*     */   extends HttpAuthenticationService
/*     */ {
/*  43 */   private static final Logger LOGGER = LoggerFactory.getLogger(YggdrasilAuthenticationService.class);
/*     */   
/*     */   @Nullable
/*     */   private final String clientToken;
/*     */   private final Gson gson;
/*     */   private final Environment environment;
/*     */   
/*     */   public YggdrasilAuthenticationService(Proxy proxy) {
/*  51 */     this(proxy, determineEnvironment());
/*     */   }
/*     */   
/*     */   public YggdrasilAuthenticationService(Proxy proxy, Environment environment) {
/*  55 */     this(proxy, (String)null, environment);
/*     */   }
/*     */   
/*     */   public YggdrasilAuthenticationService(Proxy proxy, @Nullable String clientToken) {
/*  59 */     this(proxy, clientToken, determineEnvironment());
/*     */   }
/*     */   
/*     */   public YggdrasilAuthenticationService(Proxy proxy, @Nullable String clientToken, Environment environment) {
/*  63 */     super(proxy);
/*  64 */     this.clientToken = clientToken;
/*  65 */     this.environment = environment;
/*  66 */     GsonBuilder builder = new GsonBuilder();
/*  67 */     builder.registerTypeAdapter(GameProfile.class, new GameProfileSerializer());
/*  68 */     builder.registerTypeAdapter(PropertyMap.class, new PropertyMap.Serializer());
/*  69 */     builder.registerTypeAdapter(UUID.class, new UUIDTypeAdapter());
/*  70 */     builder.registerTypeAdapter(ProfileSearchResultsResponse.class, new ProfileSearchResultsResponse.Serializer());
/*  71 */     this.gson = builder.create();
/*  72 */     LOGGER.info("Environment: " + environment.asString());
/*     */   }
/*     */   
/*     */   private static Environment determineEnvironment() {
/*  76 */     return 
/*  77 */       EnvironmentParser.getEnvironmentFromProperties()
/*  78 */       .orElse(YggdrasilEnvironment.PROD.getEnvironment());
/*     */   }
/*     */ 
/*     */   
/*     */   public UserAuthentication createUserAuthentication(Agent agent) {
/*  83 */     if (this.clientToken == null) {
/*  84 */       throw new IllegalStateException("Missing client token");
/*     */     }
/*  86 */     return (UserAuthentication)new YggdrasilUserAuthentication(this, this.clientToken, agent, this.environment);
/*     */   }
/*     */ 
/*     */   
/*     */   public MinecraftSessionService createMinecraftSessionService() {
/*  91 */     return (MinecraftSessionService)new YggdrasilMinecraftSessionService(this, this.environment);
/*     */   }
/*     */ 
/*     */   
/*     */   public GameProfileRepository createProfileRepository() {
/*  96 */     return new YggdrasilGameProfileRepository(this, this.environment);
/*     */   }
/*     */   
/*     */   protected <T extends Response> T makeRequest(URL url, Object input, Class<T> classOfT) throws AuthenticationException {
/* 100 */     return makeRequest(url, input, classOfT, (String)null);
/*     */   }
/*     */   
/*     */   protected <T extends Response> T makeRequest(URL url, Object input, Class<T> classOfT, @Nullable String authentication) throws AuthenticationException {
/*     */     try {
/* 105 */       String jsonResult = (input == null) ? performGetRequest(url, authentication) : performPostRequest(url, this.gson.toJson(input), "application/json");
/* 106 */       Response response = (Response)this.gson.fromJson(jsonResult, classOfT);
/*     */       
/* 108 */       if (response == null) {
/* 109 */         return null;
/*     */       }
/*     */       
/* 112 */       if (StringUtils.isNotBlank(response.getError())) {
/* 113 */         if ("UserMigratedException".equals(response.getCause()))
/* 114 */           throw new UserMigratedException(response.getErrorMessage()); 
/* 115 */         if ("ForbiddenOperationException".equals(response.getError()))
/* 116 */           throw new InvalidCredentialsException(response.getErrorMessage()); 
/* 117 */         if ("InsufficientPrivilegesException".equals(response.getError())) {
/* 118 */           throw new InsufficientPrivilegesException(response.getErrorMessage());
/*     */         }
/* 120 */         throw new AuthenticationException(response.getErrorMessage());
/*     */       } 
/*     */ 
/*     */       
/* 124 */       return (T)response;
/* 125 */     } catch (IOException|IllegalStateException|JsonParseException e) {
/* 126 */       throw new AuthenticationUnavailableException("Cannot contact authentication server", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class GameProfileSerializer
/*     */     implements JsonSerializer<GameProfile>, JsonDeserializer<GameProfile> {
/*     */     public GameProfile deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
/* 133 */       JsonObject object = (JsonObject)json;
/* 134 */       UUID id = object.has("id") ? (UUID)context.deserialize(object.get("id"), UUID.class) : null;
/* 135 */       String name = object.has("name") ? object.getAsJsonPrimitive("name").getAsString() : null;
/* 136 */       return new GameProfile(id, name);
/*     */     }
/*     */ 
/*     */     
/*     */     public JsonElement serialize(GameProfile src, Type typeOfSrc, JsonSerializationContext context) {
/* 141 */       JsonObject result = new JsonObject();
/* 142 */       if (src.getId() != null) {
/* 143 */         result.add("id", context.serialize(src.getId()));
/*     */       }
/* 145 */       if (src.getName() != null) {
/* 146 */         result.addProperty("name", src.getName());
/*     */       }
/* 148 */       return (JsonElement)result;
/*     */     }
/*     */   }
/*     */   
/*     */   public UserApiService createUserApiService(String accessToken) throws AuthenticationException {
/* 153 */     return new YggdrasilUserApiService(accessToken, getProxy(), this.environment);
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrasilAuthenticationService.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */