/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OutdatedTextureException
/*    */   extends InsecureTextureException
/*    */ {
/*    */   private final Date validFrom;
/*    */   private final Calendar limit;
/*    */   
/*    */   public OutdatedTextureException(Date validFrom, Calendar limit) {
/* 19 */     super("Decrypted textures payload is too old (" + validFrom + ", but we need it to be at least " + limit + ")");
/* 20 */     this.validFrom = validFrom;
/* 21 */     this.limit = limit;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\InsecureTextureException$OutdatedTextureException.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */