/*    */ package com.mojang.authlib.minecraft;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ class null
/*    */   implements TelemetrySession
/*    */ {
/*    */   public boolean isEnabled() {
/*  9 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public TelemetryPropertyContainer globalProperties() {
/* 14 */     return TelemetryEvent.EMPTY;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void eventSetupFunction(Consumer<TelemetryPropertyContainer> event) {}
/*    */ 
/*    */   
/*    */   public TelemetryEvent createNewEvent(String type) {
/* 23 */     return TelemetryEvent.EMPTY;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\TelemetrySession$1.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */