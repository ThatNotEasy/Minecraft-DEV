/*   */ package com.mojang.authlib.exceptions;
/*   */ 
/*   */ 
/*   */ public enum ErrorType
/*   */ {
/* 6 */   SERVICE_UNAVAILABLE,
/* 7 */   HTTP_ERROR,
/* 8 */   JSON_ERROR;
/*   */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\exceptions\MinecraftClientException$ErrorType.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */