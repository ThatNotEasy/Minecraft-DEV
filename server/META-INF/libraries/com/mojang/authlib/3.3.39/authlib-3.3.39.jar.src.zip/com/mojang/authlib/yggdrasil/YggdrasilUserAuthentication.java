/*     */ package com.mojang.authlib.yggdrasil;
/*     */ import com.google.common.collect.Multimap;
/*     */ import com.mojang.authlib.Agent;
/*     */ import com.mojang.authlib.AuthenticationService;
/*     */ import com.mojang.authlib.Environment;
/*     */ import com.mojang.authlib.GameProfile;
/*     */ import com.mojang.authlib.HttpAuthenticationService;
/*     */ import com.mojang.authlib.HttpUserAuthentication;
/*     */ import com.mojang.authlib.UserType;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.exceptions.InvalidCredentialsException;
/*     */ import com.mojang.authlib.yggdrasil.request.AuthenticationRequest;
/*     */ import com.mojang.authlib.yggdrasil.request.RefreshRequest;
/*     */ import com.mojang.authlib.yggdrasil.request.ValidateRequest;
/*     */ import com.mojang.authlib.yggdrasil.response.AuthenticationResponse;
/*     */ import com.mojang.authlib.yggdrasil.response.RefreshResponse;
/*     */ import com.mojang.authlib.yggdrasil.response.Response;
/*     */ import com.mojang.authlib.yggdrasil.response.User;
/*     */ import java.net.URL;
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang3.ArrayUtils;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class YggdrasilUserAuthentication extends HttpUserAuthentication {
/*  28 */   private static final Logger LOGGER = LoggerFactory.getLogger(YggdrasilUserAuthentication.class);
/*     */   
/*     */   private final URL routeAuthenticate;
/*     */   
/*     */   private final URL routeRefresh;
/*     */   
/*     */   private final URL routeValidate;
/*     */   private final URL routeInvalidate;
/*     */   private final URL routeSignout;
/*     */   private static final String STORAGE_KEY_ACCESS_TOKEN = "accessToken";
/*     */   private final Agent agent;
/*     */   private GameProfile[] profiles;
/*     */   private final String clientToken;
/*     */   private String accessToken;
/*     */   private boolean isOnline;
/*     */   
/*     */   public YggdrasilUserAuthentication(YggdrasilAuthenticationService authenticationService, String clientToken, Agent agent) {
/*  45 */     this(authenticationService, clientToken, agent, YggdrasilEnvironment.PROD.getEnvironment());
/*     */   }
/*     */   
/*     */   public YggdrasilUserAuthentication(YggdrasilAuthenticationService authenticationService, String clientToken, Agent agent, Environment env) {
/*  49 */     super(authenticationService);
/*  50 */     this.clientToken = clientToken;
/*  51 */     this.agent = agent;
/*     */     
/*  53 */     LOGGER.info("Environment: " + env.getName(), ". AuthHost: " + env.getAuthHost());
/*  54 */     this.routeAuthenticate = HttpAuthenticationService.constantURL(env.getAuthHost() + "/authenticate");
/*  55 */     this.routeRefresh = HttpAuthenticationService.constantURL(env.getAuthHost() + "/refresh");
/*  56 */     this.routeValidate = HttpAuthenticationService.constantURL(env.getAuthHost() + "/validate");
/*  57 */     this.routeInvalidate = HttpAuthenticationService.constantURL(env.getAuthHost() + "/invalidate");
/*  58 */     this.routeSignout = HttpAuthenticationService.constantURL(env.getAuthHost() + "/signout");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canLogIn() {
/*  63 */     return (!canPlayOnline() && StringUtils.isNotBlank(getUsername()) && (StringUtils.isNotBlank(getPassword()) || StringUtils.isNotBlank(getAuthenticatedToken())));
/*     */   }
/*     */ 
/*     */   
/*     */   public void logIn() throws AuthenticationException {
/*  68 */     if (StringUtils.isBlank(getUsername())) {
/*  69 */       throw new InvalidCredentialsException("Invalid username");
/*     */     }
/*     */     
/*  72 */     if (StringUtils.isNotBlank(getAuthenticatedToken())) {
/*  73 */       logInWithToken();
/*  74 */     } else if (StringUtils.isNotBlank(getPassword())) {
/*  75 */       logInWithPassword();
/*     */     } else {
/*  77 */       throw new InvalidCredentialsException("Invalid password");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void logInWithPassword() throws AuthenticationException {
/*  82 */     if (StringUtils.isBlank(getUsername())) {
/*  83 */       throw new InvalidCredentialsException("Invalid username");
/*     */     }
/*  85 */     if (StringUtils.isBlank(getPassword())) {
/*  86 */       throw new InvalidCredentialsException("Invalid password");
/*     */     }
/*     */     
/*  89 */     LOGGER.info("Logging in with username & password");
/*     */     
/*  91 */     AuthenticationRequest request = new AuthenticationRequest(getAgent(), getUsername(), getPassword(), this.clientToken);
/*  92 */     AuthenticationResponse response = getAuthenticationService().<AuthenticationResponse>makeRequest(this.routeAuthenticate, request, AuthenticationResponse.class);
/*     */     
/*  94 */     if (!response.getClientToken().equals(this.clientToken)) {
/*  95 */       throw new AuthenticationException("Server requested we change our client token. Don't know how to handle this!");
/*     */     }
/*     */     
/*  98 */     if (response.getSelectedProfile() != null) {
/*  99 */       setUserType(response.getSelectedProfile().isLegacy() ? UserType.LEGACY : UserType.MOJANG);
/* 100 */     } else if (ArrayUtils.isNotEmpty((Object[])response.getAvailableProfiles())) {
/* 101 */       setUserType(response.getAvailableProfiles()[0].isLegacy() ? UserType.LEGACY : UserType.MOJANG);
/*     */     } 
/*     */     
/* 104 */     User user = response.getUser();
/*     */     
/* 106 */     if (user != null && user.getId() != null) {
/* 107 */       setUserid(user.getId());
/*     */     } else {
/* 109 */       setUserid(getUsername());
/*     */     } 
/*     */     
/* 112 */     this.isOnline = true;
/* 113 */     this.accessToken = response.getAccessToken();
/* 114 */     this.profiles = response.getAvailableProfiles();
/* 115 */     setSelectedProfile(response.getSelectedProfile());
/* 116 */     getModifiableUserProperties().clear();
/*     */     
/* 118 */     updateUserProperties(user);
/*     */   }
/*     */   
/*     */   protected void updateUserProperties(User user) {
/* 122 */     if (user == null) {
/*     */       return;
/*     */     }
/*     */     
/* 126 */     if (user.getProperties() != null) {
/* 127 */       getModifiableUserProperties().putAll((Multimap)user.getProperties());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void logInWithToken() throws AuthenticationException {
/* 132 */     if (StringUtils.isBlank(getUserID())) {
/* 133 */       if (StringUtils.isBlank(getUsername())) {
/* 134 */         setUserid(getUsername());
/*     */       } else {
/* 136 */         throw new InvalidCredentialsException("Invalid uuid & username");
/*     */       } 
/*     */     }
/* 139 */     if (StringUtils.isBlank(getAuthenticatedToken())) {
/* 140 */       throw new InvalidCredentialsException("Invalid access token");
/*     */     }
/*     */     
/* 143 */     LOGGER.info("Logging in with access token");
/*     */     
/* 145 */     if (checkTokenValidity()) {
/* 146 */       LOGGER.debug("Skipping refresh call as we're safely logged in.");
/* 147 */       this.isOnline = true;
/*     */       
/*     */       return;
/*     */     } 
/* 151 */     RefreshRequest request = new RefreshRequest(getAuthenticatedToken(), this.clientToken);
/* 152 */     RefreshResponse response = getAuthenticationService().<RefreshResponse>makeRequest(this.routeRefresh, request, RefreshResponse.class);
/*     */     
/* 154 */     if (!response.getClientToken().equals(this.clientToken)) {
/* 155 */       throw new AuthenticationException("Server requested we change our client token. Don't know how to handle this!");
/*     */     }
/*     */     
/* 158 */     if (response.getSelectedProfile() != null) {
/* 159 */       setUserType(response.getSelectedProfile().isLegacy() ? UserType.LEGACY : UserType.MOJANG);
/* 160 */     } else if (ArrayUtils.isNotEmpty((Object[])response.getAvailableProfiles())) {
/* 161 */       setUserType(response.getAvailableProfiles()[0].isLegacy() ? UserType.LEGACY : UserType.MOJANG);
/*     */     } 
/*     */     
/* 164 */     if (response.getUser() != null && response.getUser().getId() != null) {
/* 165 */       setUserid(response.getUser().getId());
/*     */     } else {
/* 167 */       setUserid(getUsername());
/*     */     } 
/*     */     
/* 170 */     this.isOnline = true;
/* 171 */     this.accessToken = response.getAccessToken();
/* 172 */     this.profiles = response.getAvailableProfiles();
/* 173 */     setSelectedProfile(response.getSelectedProfile());
/* 174 */     getModifiableUserProperties().clear();
/*     */     
/* 176 */     updateUserProperties(response.getUser());
/*     */   }
/*     */   
/*     */   protected boolean checkTokenValidity() throws AuthenticationException {
/* 180 */     ValidateRequest request = new ValidateRequest(getAuthenticatedToken(), this.clientToken);
/*     */     try {
/* 182 */       getAuthenticationService().makeRequest(this.routeValidate, request, Response.class);
/* 183 */       return true;
/* 184 */     } catch (AuthenticationException ignored) {
/* 185 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void logOut() {
/* 191 */     super.logOut();
/*     */     
/* 193 */     this.accessToken = null;
/* 194 */     this.profiles = null;
/* 195 */     this.isOnline = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public GameProfile[] getAvailableProfiles() {
/* 200 */     return this.profiles;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLoggedIn() {
/* 205 */     return StringUtils.isNotBlank(this.accessToken);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canPlayOnline() {
/* 210 */     return (isLoggedIn() && getSelectedProfile() != null && this.isOnline);
/*     */   }
/*     */ 
/*     */   
/*     */   public void selectGameProfile(GameProfile profile) throws AuthenticationException {
/* 215 */     if (!isLoggedIn()) {
/* 216 */       throw new AuthenticationException("Cannot change game profile whilst not logged in");
/*     */     }
/* 218 */     if (getSelectedProfile() != null) {
/* 219 */       throw new AuthenticationException("Cannot change game profile. You must log out and back in.");
/*     */     }
/* 221 */     if (profile == null || !ArrayUtils.contains((Object[])this.profiles, profile)) {
/* 222 */       throw new IllegalArgumentException("Invalid profile '" + profile + "'");
/*     */     }
/*     */     
/* 225 */     RefreshRequest request = new RefreshRequest(getAuthenticatedToken(), this.clientToken, profile);
/* 226 */     RefreshResponse response = getAuthenticationService().<RefreshResponse>makeRequest(this.routeRefresh, request, RefreshResponse.class);
/*     */     
/* 228 */     if (!response.getClientToken().equals(this.clientToken)) {
/* 229 */       throw new AuthenticationException("Server requested we change our client token. Don't know how to handle this!");
/*     */     }
/*     */     
/* 232 */     this.isOnline = true;
/* 233 */     this.accessToken = response.getAccessToken();
/* 234 */     setSelectedProfile(response.getSelectedProfile());
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadFromStorage(Map<String, Object> credentials) {
/* 239 */     super.loadFromStorage(credentials);
/*     */     
/* 241 */     this.accessToken = String.valueOf(credentials.get("accessToken"));
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Object> saveForStorage() {
/* 246 */     Map<String, Object> result = super.saveForStorage();
/*     */     
/* 248 */     if (StringUtils.isNotBlank(getAuthenticatedToken())) {
/* 249 */       result.put("accessToken", getAuthenticatedToken());
/*     */     }
/*     */     
/* 252 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getSessionToken() {
/* 260 */     if (isLoggedIn() && getSelectedProfile() != null && canPlayOnline()) {
/* 261 */       return String.format("token:%s:%s", new Object[] { getAuthenticatedToken(), getSelectedProfile().getId() });
/*     */     }
/* 263 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAuthenticatedToken() {
/* 269 */     return this.accessToken;
/*     */   }
/*     */   
/*     */   public Agent getAgent() {
/* 273 */     return this.agent;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 278 */     return "YggdrasilAuthenticationService{agent=" + this.agent + ", profiles=" + 
/*     */       
/* 280 */       Arrays.toString((Object[])this.profiles) + ", selectedProfile=" + 
/* 281 */       getSelectedProfile() + ", username='" + 
/* 282 */       getUsername() + "', isLoggedIn=" + 
/* 283 */       isLoggedIn() + ", userType=" + 
/* 284 */       getUserType() + ", canPlayOnline=" + 
/* 285 */       canPlayOnline() + ", accessToken='" + this.accessToken + "', clientToken='" + this.clientToken + "'}";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public YggdrasilAuthenticationService getAuthenticationService() {
/* 293 */     return (YggdrasilAuthenticationService)super.getAuthenticationService();
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrasilUserAuthentication.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */