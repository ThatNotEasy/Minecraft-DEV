/*    */ package com.mojang.authlib.properties;
/*    */ 
/*    */ import java.security.InvalidKeyException;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.security.PublicKey;
/*    */ import java.security.Signature;
/*    */ import java.security.SignatureException;
/*    */ import java.util.Base64;
/*    */ 
/*    */ public class Property {
/*    */   private final String name;
/*    */   private final String value;
/*    */   private final String signature;
/*    */   
/*    */   public Property(String value, String name) {
/* 16 */     this(value, name, null);
/*    */   }
/*    */   
/*    */   public Property(String name, String value, String signature) {
/* 20 */     this.name = name;
/* 21 */     this.value = value;
/* 22 */     this.signature = signature;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 26 */     return this.name;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 30 */     return this.value;
/*    */   }
/*    */   
/*    */   public String getSignature() {
/* 34 */     return this.signature;
/*    */   }
/*    */   
/*    */   public boolean hasSignature() {
/* 38 */     return (this.signature != null);
/*    */   }
/*    */   
/*    */   public boolean isSignatureValid(PublicKey publicKey) {
/*    */     try {
/* 43 */       Signature signature = Signature.getInstance("SHA1withRSA");
/* 44 */       signature.initVerify(publicKey);
/* 45 */       signature.update(this.value.getBytes());
/* 46 */       return signature.verify(Base64.getDecoder().decode(this.signature));
/* 47 */     } catch (NoSuchAlgorithmException e) {
/* 48 */       e.printStackTrace();
/* 49 */     } catch (InvalidKeyException e) {
/* 50 */       e.printStackTrace();
/* 51 */     } catch (SignatureException e) {
/* 52 */       e.printStackTrace();
/*    */     } 
/* 54 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\properties\Property.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */