/*    */ package com.mojang.authlib.yggdrasil.response;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ public class UserAttributesResponse
/*    */   extends Response {
/*    */   @Nullable
/*    */   private Privileges privileges;
/*    */   @Nullable
/*    */   private ProfanityFilterPreferences profanityFilterPreferences;
/*    */   
/*    */   @Nullable
/*    */   public Privileges getPrivileges() {
/* 14 */     return this.privileges;
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public ProfanityFilterPreferences getProfanityFilterPreferences() {
/* 19 */     return this.profanityFilterPreferences;
/*    */   }
/*    */   
/*    */   public static class Privileges {
/*    */     @Nullable
/*    */     private Privilege onlineChat;
/*    */     @Nullable
/*    */     private Privilege multiplayerServer;
/*    */     @Nullable
/*    */     private Privilege multiplayerRealms;
/*    */     @Nullable
/*    */     private Privilege telemetry;
/*    */     
/*    */     public boolean getOnlineChat() {
/* 33 */       return (this.onlineChat != null && this.onlineChat.enabled);
/*    */     }
/*    */     
/*    */     public boolean getMultiplayerServer() {
/* 37 */       return (this.multiplayerServer != null && this.multiplayerServer.enabled);
/*    */     }
/*    */     
/*    */     public boolean getMultiplayerRealms() {
/* 41 */       return (this.multiplayerRealms != null && this.multiplayerRealms.enabled);
/*    */     } public class Privilege {
/*    */       private boolean enabled; }
/*    */     public boolean getTelemetry() {
/* 45 */       return (this.telemetry != null && this.telemetry.enabled);
/*    */     }
/*    */   }
/*    */   
/*    */   public class Privilege
/*    */   {
/*    */     private boolean enabled;
/*    */   }
/*    */   
/*    */   public static class ProfanityFilterPreferences
/*    */   {
/*    */     public boolean isEnabled() {
/* 57 */       return this.profanityFilterOn;
/*    */     }
/*    */     
/*    */     private boolean profanityFilterOn;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\response\UserAttributesResponse.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */