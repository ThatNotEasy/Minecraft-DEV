/*    */ package com.mojang.authlib.yggdrasil.request;
/*    */ 
/*    */ import com.google.gson.JsonObject;
/*    */ import java.time.Instant;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TelemetryEventsRequest
/*    */ {
/*    */   public final List<Event> events;
/*    */   
/*    */   public TelemetryEventsRequest(List<Event> events) {
/* 12 */     this.events = events;
/*    */   }
/*    */   
/*    */   public static class Event {
/*    */     public final String source;
/*    */     public final String name;
/*    */     public final long timestamp;
/*    */     public final JsonObject data;
/*    */     
/*    */     public Event(String source, String name, Instant timestamp, JsonObject data) {
/* 22 */       this.source = source;
/* 23 */       this.name = name;
/* 24 */       this.timestamp = timestamp.getEpochSecond();
/* 25 */       this.data = data;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\request\TelemetryEventsRequest.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */