/*    */ package com.mojang.authlib.yggdrasil;
/*    */ 
/*    */ import com.mojang.authlib.Environment;
/*    */ import java.util.Optional;
/*    */ import java.util.stream.Stream;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ public enum YggdrasilEnvironment
/*    */ {
/* 10 */   PROD("https://authserver.mojang.com", "https://api.mojang.com", "https://sessionserver.mojang.com", "https://api.minecraftservices.com"),
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 16 */   STAGING("https://yggdrasil-auth-staging.mojang.com", "https://api-staging.mojang.com", "https://api-sb-staging.minecraftservices.com", "https://api-staging.minecraftservices.com");
/*    */ 
/*    */ 
/*    */   
/*    */   private final Environment environment;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   YggdrasilEnvironment(String authHost, String accountsHost, String sessionHost, String servicesHost) {
/* 26 */     this.environment = Environment.create(authHost, accountsHost, sessionHost, servicesHost, name());
/*    */   }
/*    */   
/*    */   public Environment getEnvironment() {
/* 30 */     return this.environment;
/*    */   }
/*    */   
/*    */   public static Optional<Environment> fromString(@Nullable String value) {
/* 34 */     return 
/* 35 */       Stream.<YggdrasilEnvironment>of(values())
/* 36 */       .filter(env -> (value != null && value.equalsIgnoreCase(env.name())))
/* 37 */       .findFirst()
/* 38 */       .map(YggdrasilEnvironment::getEnvironment);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrasilEnvironment.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */