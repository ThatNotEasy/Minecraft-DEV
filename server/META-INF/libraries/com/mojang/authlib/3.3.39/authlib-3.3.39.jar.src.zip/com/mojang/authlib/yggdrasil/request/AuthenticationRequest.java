/*    */ package com.mojang.authlib.yggdrasil.request;
/*    */ 
/*    */ import com.mojang.authlib.Agent;
/*    */ 
/*    */ public class AuthenticationRequest {
/*    */   private Agent agent;
/*    */   private String username;
/*    */   private String password;
/*    */   private String clientToken;
/*    */   private boolean requestUser = true;
/*    */   
/*    */   public AuthenticationRequest(Agent agent, String username, String password, String clientToken) {
/* 13 */     this.agent = agent;
/* 14 */     this.username = username;
/* 15 */     this.password = password;
/* 16 */     this.clientToken = clientToken;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\request\AuthenticationRequest.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */