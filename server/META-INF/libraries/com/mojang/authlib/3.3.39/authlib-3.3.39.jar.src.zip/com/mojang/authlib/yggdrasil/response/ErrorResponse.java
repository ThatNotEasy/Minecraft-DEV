/*    */ package com.mojang.authlib.yggdrasil.response;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.StringJoiner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ErrorResponse
/*    */ {
/*    */   private final String path;
/*    */   private final String error;
/*    */   private final String errorMessage;
/*    */   private final Map<String, Object> details;
/*    */   
/*    */   public ErrorResponse(String path, String error, String errorMessage, Map<String, Object> details) {
/* 23 */     this.path = path;
/* 24 */     this.error = error;
/* 25 */     this.errorMessage = errorMessage;
/* 26 */     this.details = details;
/*    */   }
/*    */   
/*    */   public String getPath() {
/* 30 */     return this.path;
/*    */   }
/*    */   
/*    */   public String getError() {
/* 34 */     return this.error;
/*    */   }
/*    */   
/*    */   public Map<String, Object> getDetails() {
/* 38 */     return this.details;
/*    */   }
/*    */   
/*    */   public String getErrorMessage() {
/* 42 */     return this.errorMessage;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 47 */     return (new StringJoiner(", ", ErrorResponse.class.getSimpleName() + "[", "]"))
/* 48 */       .add("path='" + this.path + "'")
/* 49 */       .add("error='" + this.error + "'")
/* 50 */       .add("details=" + this.details)
/* 51 */       .add("errorMessage='" + this.errorMessage + "'")
/* 52 */       .toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\response\ErrorResponse.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */