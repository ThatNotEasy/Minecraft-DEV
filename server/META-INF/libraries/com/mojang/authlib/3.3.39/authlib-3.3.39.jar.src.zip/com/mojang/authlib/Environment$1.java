/*    */ package com.mojang.authlib;
/*    */ 
/*    */ import java.util.StringJoiner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements Environment
/*    */ {
/*    */   public String getAuthHost() {
/* 24 */     return auth;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getAccountsHost() {
/* 29 */     return account;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getSessionHost() {
/* 34 */     return session;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getServicesHost() {
/* 39 */     return services;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 44 */     return name;
/*    */   }
/*    */ 
/*    */   
/*    */   public String asString() {
/* 49 */     return (new StringJoiner(", ", "", ""))
/* 50 */       .add("authHost='" + getAuthHost() + "'")
/* 51 */       .add("accountsHost='" + getAccountsHost() + "'")
/* 52 */       .add("sessionHost='" + getSessionHost() + "'")
/* 53 */       .add("servicesHost='" + getServicesHost() + "'")
/* 54 */       .add("name='" + getName() + "'")
/* 55 */       .toString();
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\Environment$1.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */