package com.mojang.authlib.minecraft;

class null implements TelemetryEvent {
  public void addProperty(String id, String value) {}
  
  public void addProperty(String id, int value) {}
  
  public void addProperty(String id, boolean value) {}
  
  public void addNullProperty(String id) {}
  
  public void send() {}
}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\minecraft\TelemetryEvent$1.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */