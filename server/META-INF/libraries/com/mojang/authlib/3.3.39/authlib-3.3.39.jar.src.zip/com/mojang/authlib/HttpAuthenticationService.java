/*     */ package com.mojang.authlib;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.net.URLEncoder;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.lang3.Validate;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public abstract class HttpAuthenticationService
/*     */   extends BaseAuthenticationService {
/*  22 */   private static final Logger LOGGER = LoggerFactory.getLogger(HttpAuthenticationService.class);
/*     */   
/*     */   private final Proxy proxy;
/*     */   
/*     */   protected HttpAuthenticationService(Proxy proxy) {
/*  27 */     Validate.notNull(proxy);
/*  28 */     this.proxy = proxy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Proxy getProxy() {
/*  37 */     return this.proxy;
/*     */   }
/*     */   
/*     */   protected HttpURLConnection createUrlConnection(URL url) throws IOException {
/*  41 */     Validate.notNull(url);
/*  42 */     LOGGER.debug("Opening connection to " + url);
/*  43 */     HttpURLConnection connection = (HttpURLConnection)url.openConnection(this.proxy);
/*  44 */     connection.setConnectTimeout(15000);
/*  45 */     connection.setReadTimeout(15000);
/*  46 */     connection.setUseCaches(false);
/*  47 */     return connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String performPostRequest(URL url, String post, String contentType) throws IOException {
/*  64 */     Validate.notNull(url);
/*  65 */     Validate.notNull(post);
/*  66 */     Validate.notNull(contentType);
/*  67 */     HttpURLConnection connection = createUrlConnection(url);
/*  68 */     byte[] postAsBytes = post.getBytes(StandardCharsets.UTF_8);
/*     */     
/*  70 */     connection.setRequestProperty("Content-Type", contentType + "; charset=utf-8");
/*  71 */     connection.setRequestProperty("Content-Length", "" + postAsBytes.length);
/*  72 */     connection.setDoOutput(true);
/*     */     
/*  74 */     LOGGER.debug("Writing POST data to " + url + ": " + post);
/*     */     
/*  76 */     OutputStream outputStream = null;
/*     */     try {
/*  78 */       outputStream = connection.getOutputStream();
/*  79 */       IOUtils.write(postAsBytes, outputStream);
/*     */     } finally {
/*  81 */       IOUtils.closeQuietly(outputStream);
/*     */     } 
/*     */     
/*  84 */     LOGGER.debug("Reading data from " + url);
/*     */     
/*  86 */     InputStream inputStream = null;
/*     */     try {
/*  88 */       inputStream = connection.getInputStream();
/*  89 */       String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
/*  90 */       LOGGER.debug("Successful read, server response was " + connection.getResponseCode());
/*  91 */       LOGGER.debug("Response: " + result);
/*  92 */       return result;
/*  93 */     } catch (IOException e) {
/*  94 */       IOUtils.closeQuietly(inputStream);
/*  95 */       inputStream = connection.getErrorStream();
/*     */       
/*  97 */       if (inputStream != null) {
/*  98 */         LOGGER.debug("Reading error page from " + url);
/*  99 */         String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
/* 100 */         LOGGER.debug("Successful read, server response was " + connection.getResponseCode());
/* 101 */         LOGGER.debug("Response: " + result);
/* 102 */         return result;
/*     */       } 
/* 104 */       LOGGER.debug("Request failed", e);
/* 105 */       throw e;
/*     */     } finally {
/*     */       
/* 108 */       IOUtils.closeQuietly(inputStream);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String performGetRequest(URL url) throws IOException {
/* 113 */     return performGetRequest(url, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String performGetRequest(URL url, @Nullable String authentication) throws IOException {
/* 129 */     Validate.notNull(url);
/* 130 */     HttpURLConnection connection = createUrlConnection(url);
/*     */     
/* 132 */     if (authentication != null) {
/* 133 */       connection.setRequestProperty("Authorization", authentication);
/*     */     }
/*     */     
/* 136 */     LOGGER.debug("Reading data from " + url);
/*     */     
/* 138 */     InputStream inputStream = null;
/*     */     try {
/* 140 */       inputStream = connection.getInputStream();
/* 141 */       String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
/* 142 */       LOGGER.debug("Successful read, server response was " + connection.getResponseCode());
/* 143 */       LOGGER.debug("Response: " + result);
/* 144 */       return result;
/* 145 */     } catch (IOException e) {
/* 146 */       IOUtils.closeQuietly(inputStream);
/* 147 */       inputStream = connection.getErrorStream();
/*     */       
/* 149 */       if (inputStream != null) {
/* 150 */         LOGGER.debug("Reading error page from " + url);
/* 151 */         String result = IOUtils.toString(inputStream, StandardCharsets.UTF_8);
/* 152 */         LOGGER.debug("Successful read, server response was " + connection.getResponseCode());
/* 153 */         LOGGER.debug("Response: " + result);
/* 154 */         return result;
/*     */       } 
/* 156 */       LOGGER.debug("Request failed", e);
/* 157 */       throw e;
/*     */     } finally {
/*     */       
/* 160 */       IOUtils.closeQuietly(inputStream);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL constantURL(String url) {
/*     */     try {
/* 174 */       return new URL(url);
/* 175 */     } catch (MalformedURLException ex) {
/* 176 */       throw new Error("Couldn't create constant for " + url, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String buildQuery(Map<String, Object> query) {
/* 187 */     if (query == null) {
/* 188 */       return "";
/*     */     }
/* 190 */     StringBuilder builder = new StringBuilder();
/*     */     
/* 192 */     for (Map.Entry<String, Object> entry : query.entrySet()) {
/* 193 */       if (builder.length() > 0) {
/* 194 */         builder.append('&');
/*     */       }
/*     */       
/*     */       try {
/* 198 */         builder.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
/* 199 */       } catch (UnsupportedEncodingException e) {
/* 200 */         LOGGER.error("Unexpected exception building query", e);
/*     */       } 
/*     */       
/* 203 */       if (entry.getValue() != null) {
/* 204 */         builder.append('=');
/*     */         try {
/* 206 */           builder.append(URLEncoder.encode(entry.getValue().toString(), "UTF-8"));
/* 207 */         } catch (UnsupportedEncodingException e) {
/* 208 */           LOGGER.error("Unexpected exception building query", e);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 213 */     return builder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static URL concatenateURL(URL url, String query) {
/*     */     try {
/* 225 */       if (url.getQuery() != null && url.getQuery().length() > 0) {
/* 226 */         return new URL(url.getProtocol(), url.getHost(), url.getPort(), url.getFile() + "&" + url.getFile());
/*     */       }
/* 228 */       return new URL(url.getProtocol(), url.getHost(), url.getPort(), url.getFile() + "?" + url.getFile());
/*     */     }
/* 230 */     catch (MalformedURLException ex) {
/* 231 */       throw new IllegalArgumentException("Could not concatenate given URL with GET arguments!", ex);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\HttpAuthenticationService.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */