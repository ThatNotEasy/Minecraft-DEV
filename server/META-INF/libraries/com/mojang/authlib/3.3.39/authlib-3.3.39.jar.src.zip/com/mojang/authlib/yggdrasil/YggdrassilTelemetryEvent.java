/*    */ package com.mojang.authlib.yggdrasil;
/*    */ 
/*    */ import com.google.gson.JsonElement;
/*    */ import com.google.gson.JsonNull;
/*    */ import com.google.gson.JsonObject;
/*    */ import com.mojang.authlib.minecraft.TelemetryEvent;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ public class YggdrassilTelemetryEvent implements TelemetryEvent {
/*    */   private final YggdrassilTelemetrySession service;
/*    */   private final String type;
/*    */   @Nullable
/* 13 */   private JsonObject data = new JsonObject();
/*    */ 
/*    */   
/*    */   YggdrassilTelemetryEvent(YggdrassilTelemetrySession service, String type) {
/* 17 */     this.service = service;
/* 18 */     this.type = type;
/*    */   }
/*    */   
/*    */   private JsonObject data() {
/* 22 */     if (this.data == null) {
/* 23 */       throw new IllegalStateException("Event already sent");
/*    */     }
/* 25 */     return this.data;
/*    */   }
/*    */ 
/*    */   
/*    */   public void addProperty(String id, String value) {
/* 30 */     data().addProperty(id, value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void addProperty(String id, int value) {
/* 35 */     data().addProperty(id, Integer.valueOf(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addProperty(String id, boolean value) {
/* 40 */     data().addProperty(id, Boolean.valueOf(value));
/*    */   }
/*    */ 
/*    */   
/*    */   public void addNullProperty(String id) {
/* 45 */     data().add(id, (JsonElement)JsonNull.INSTANCE);
/*    */   }
/*    */ 
/*    */   
/*    */   public void send() {
/* 50 */     this.service.sendEvent(this.type, this.data);
/* 51 */     this.data = null;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrassilTelemetryEvent.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */