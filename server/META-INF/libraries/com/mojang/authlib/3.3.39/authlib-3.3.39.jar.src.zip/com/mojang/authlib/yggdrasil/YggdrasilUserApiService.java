/*     */ package com.mojang.authlib.yggdrasil;
/*     */ 
/*     */ import com.google.common.collect.ImmutableSet;
/*     */ import com.mojang.authlib.Environment;
/*     */ import com.mojang.authlib.HttpAuthenticationService;
/*     */ import com.mojang.authlib.exceptions.AuthenticationException;
/*     */ import com.mojang.authlib.exceptions.MinecraftClientException;
/*     */ import com.mojang.authlib.exceptions.MinecraftClientHttpException;
/*     */ import com.mojang.authlib.minecraft.TelemetrySession;
/*     */ import com.mojang.authlib.minecraft.UserApiService;
/*     */ import com.mojang.authlib.minecraft.client.MinecraftClient;
/*     */ import com.mojang.authlib.yggdrasil.response.BlockListResponse;
/*     */ import com.mojang.authlib.yggdrasil.response.UserAttributesResponse;
/*     */ import java.net.Proxy;
/*     */ import java.net.URL;
/*     */ import java.time.Instant;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ public class YggdrasilUserApiService
/*     */   implements UserApiService {
/*     */   private static final long BLOCKLIST_REQUEST_COOLDOWN_SECONDS = 120L;
/*  25 */   private static final UUID ZERO_UUID = new UUID(0L, 0L);
/*     */   
/*     */   private final URL routePrivileges;
/*     */   
/*     */   private final URL routeBlocklist;
/*     */   private final MinecraftClient minecraftClient;
/*     */   private final Environment environment;
/*  32 */   private UserApiService.UserProperties properties = OFFLINE_PROPERTIES;
/*     */   
/*     */   @Nullable
/*     */   private Instant nextAcceptableBlockRequest;
/*     */   @Nullable
/*     */   private Set<UUID> blockList;
/*     */   
/*     */   public YggdrasilUserApiService(String accessToken, Proxy proxy, Environment env) throws AuthenticationException {
/*  40 */     this.minecraftClient = new MinecraftClient(accessToken, proxy);
/*  41 */     this.environment = env;
/*  42 */     this.routePrivileges = HttpAuthenticationService.constantURL(env.getServicesHost() + "/player/attributes");
/*  43 */     this.routeBlocklist = HttpAuthenticationService.constantURL(env.getServicesHost() + "/privacy/blocklist");
/*  44 */     fetchProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   public UserApiService.UserProperties properties() {
/*  49 */     return this.properties;
/*     */   }
/*     */ 
/*     */   
/*     */   public TelemetrySession newTelemetrySession(Executor executor) {
/*  54 */     if (!this.properties.flag(UserApiService.UserFlag.TELEMETRY_ENABLED)) {
/*  55 */       return TelemetrySession.DISABLED;
/*     */     }
/*  57 */     return new YggdrassilTelemetrySession(this.minecraftClient, this.environment, executor);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBlockedPlayer(UUID playerID) {
/*  62 */     if (playerID.equals(ZERO_UUID)) {
/*  63 */       return false;
/*     */     }
/*     */     
/*  66 */     if (this.blockList == null) {
/*  67 */       this.blockList = fetchBlockList();
/*  68 */       if (this.blockList == null) {
/*  69 */         return false;
/*     */       }
/*     */     } 
/*     */     
/*  73 */     return this.blockList.contains(playerID);
/*     */   }
/*     */ 
/*     */   
/*     */   public void refreshBlockList() {
/*  78 */     if (this.blockList == null || canMakeBlockListRequest()) {
/*  79 */       this.blockList = forceFetchBlockList();
/*     */     }
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   private Set<UUID> fetchBlockList() {
/*  85 */     if (!canMakeBlockListRequest()) {
/*  86 */       return null;
/*     */     }
/*  88 */     return forceFetchBlockList();
/*     */   }
/*     */   
/*     */   private boolean canMakeBlockListRequest() {
/*  92 */     return (this.nextAcceptableBlockRequest == null || Instant.now().isAfter(this.nextAcceptableBlockRequest));
/*     */   }
/*     */   
/*     */   private Set<UUID> forceFetchBlockList() {
/*  96 */     this.nextAcceptableBlockRequest = Instant.now().plusSeconds(120L);
/*     */     try {
/*  98 */       BlockListResponse response = (BlockListResponse)this.minecraftClient.get(this.routeBlocklist, BlockListResponse.class);
/*  99 */       return response.getBlockedProfiles();
/* 100 */     } catch (MinecraftClientHttpException e) {
/*     */ 
/*     */       
/* 103 */       return null;
/* 104 */     } catch (MinecraftClientException e) {
/*     */ 
/*     */       
/* 107 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fetchProperties() throws AuthenticationException {
/*     */     try {
/* 113 */       UserAttributesResponse response = (UserAttributesResponse)this.minecraftClient.get(this.routePrivileges, UserAttributesResponse.class);
/* 114 */       ImmutableSet.Builder<UserApiService.UserFlag> flags = ImmutableSet.builder();
/*     */       
/* 116 */       UserAttributesResponse.Privileges privileges = response.getPrivileges();
/* 117 */       if (privileges != null) {
/* 118 */         addFlagIfUserHasPrivilege(privileges.getOnlineChat(), UserApiService.UserFlag.CHAT_ALLOWED, flags);
/* 119 */         addFlagIfUserHasPrivilege(privileges.getMultiplayerServer(), UserApiService.UserFlag.SERVERS_ALLOWED, flags);
/* 120 */         addFlagIfUserHasPrivilege(privileges.getMultiplayerRealms(), UserApiService.UserFlag.REALMS_ALLOWED, flags);
/* 121 */         addFlagIfUserHasPrivilege(privileges.getTelemetry(), UserApiService.UserFlag.TELEMETRY_ENABLED, flags);
/*     */       } 
/*     */       
/* 124 */       UserAttributesResponse.ProfanityFilterPreferences profanityFilterPreferences = response.getProfanityFilterPreferences();
/* 125 */       if (profanityFilterPreferences != null && profanityFilterPreferences.isEnabled()) {
/* 126 */         flags.add(UserApiService.UserFlag.PROFANITY_FILTER_ENABLED);
/*     */       }
/*     */       
/* 129 */       this.properties = new UserApiService.UserProperties((Set)flags.build());
/* 130 */     } catch (MinecraftClientHttpException e) {
/*     */       
/* 132 */       throw e.toAuthenticationException();
/* 133 */     } catch (MinecraftClientException e) {
/*     */ 
/*     */       
/* 136 */       throw e.toAuthenticationException();
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void addFlagIfUserHasPrivilege(boolean privilege, UserApiService.UserFlag value, ImmutableSet.Builder<UserApiService.UserFlag> output) {
/* 141 */     if (privilege)
/* 142 */       output.add(value); 
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\YggdrasilUserApiService.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */