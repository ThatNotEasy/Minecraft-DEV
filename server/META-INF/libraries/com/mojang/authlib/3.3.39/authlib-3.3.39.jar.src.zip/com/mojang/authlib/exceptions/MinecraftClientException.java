/*    */ package com.mojang.authlib.exceptions;
/*    */ public class MinecraftClientException extends RuntimeException {
/*    */   protected final ErrorType type;
/*    */   
/*    */   public enum ErrorType {
/*  6 */     SERVICE_UNAVAILABLE,
/*  7 */     HTTP_ERROR,
/*  8 */     JSON_ERROR;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected MinecraftClientException(ErrorType type, String message) {
/* 14 */     super(message);
/* 15 */     this.type = type;
/*    */   }
/*    */   
/*    */   public MinecraftClientException(ErrorType type, String message, Throwable cause) {
/* 19 */     super(message, cause);
/* 20 */     this.type = type;
/*    */   }
/*    */   
/*    */   public ErrorType getType() {
/* 24 */     return this.type;
/*    */   }
/*    */   
/*    */   public AuthenticationException toAuthenticationException() {
/* 28 */     return new AuthenticationException(this);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\exceptions\MinecraftClientException.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */