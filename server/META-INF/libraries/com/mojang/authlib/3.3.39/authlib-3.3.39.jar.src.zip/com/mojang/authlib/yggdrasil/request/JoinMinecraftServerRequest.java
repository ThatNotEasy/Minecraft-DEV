package com.mojang.authlib.yggdrasil.request;

import java.util.UUID;

public class JoinMinecraftServerRequest {
  public String accessToken;
  
  public UUID selectedProfile;
  
  public String serverId;
}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\authlib\3.3.39\authlib-3.3.39.jar!\com\mojang\authlib\yggdrasil\request\JoinMinecraftServerRequest.class
 * Java compiler version: 16 (60.0)
 * JD-Core Version:       1.1.3
 */