/*     */ package com.mojang.logging.plugins;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.logging.log4j.Level;
/*     */ import org.apache.logging.log4j.Marker;
/*     */ import org.apache.logging.log4j.core.LogEvent;
/*     */ import org.apache.logging.log4j.core.config.plugins.Plugin;
/*     */ import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
/*     */ import org.apache.logging.log4j.core.config.plugins.PluginFactory;
/*     */ import org.apache.logging.log4j.core.layout.AbstractStringLayout;
/*     */ import org.apache.logging.log4j.core.util.Throwables;
/*     */ import org.apache.logging.log4j.core.util.Transform;
/*     */ import org.apache.logging.log4j.message.Message;
/*     */ import org.apache.logging.log4j.message.MultiformatMessage;
/*     */ import org.apache.logging.log4j.util.Strings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Plugin(name = "LegacyXMLLayout", category = "Core", elementType = "layout", printObject = true)
/*     */ public class LegacyXMLLayout
/*     */   extends AbstractStringLayout
/*     */ {
/*     */   private static final String XML_NAMESPACE = "http://logging.apache.org/log4j/2.0/events";
/*     */   private static final String ROOT_TAG = "Events";
/*     */   private static final int DEFAULT_SIZE = 256;
/*     */   private static final String DEFAULT_EOL = "\r\n";
/*     */   private static final String COMPACT_EOL = "";
/*     */   private static final String DEFAULT_INDENT = "  ";
/*     */   private static final String COMPACT_INDENT = "";
/*     */   private static final String DEFAULT_NS_PREFIX = "log4j";
/*  99 */   private static final String[] FORMATS = new String[] { "xml" };
/*     */   
/*     */   private final boolean locationInfo;
/*     */   
/*     */   private final boolean properties;
/*     */   private final boolean complete;
/*     */   private final String namespacePrefix;
/*     */   private final String eol;
/*     */   private final String indent1;
/*     */   private final String indent2;
/*     */   private final String indent3;
/*     */   
/*     */   protected LegacyXMLLayout(boolean locationInfo, boolean properties, boolean complete, boolean compact, String nsPrefix, Charset charset) {
/* 112 */     super(charset);
/* 113 */     this.locationInfo = locationInfo;
/* 114 */     this.properties = properties;
/* 115 */     this.complete = complete;
/* 116 */     this.eol = compact ? "" : "\r\n";
/* 117 */     this.indent1 = compact ? "" : "  ";
/* 118 */     this.indent2 = this.indent1 + this.indent1;
/* 119 */     this.indent3 = this.indent2 + this.indent2;
/* 120 */     this.namespacePrefix = (Strings.isEmpty(nsPrefix) ? "log4j" : nsPrefix) + ":";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toSerializable(LogEvent event) {
/* 131 */     StringBuilder buf = new StringBuilder(256);
/*     */     
/* 133 */     buf.append(this.indent1);
/* 134 */     buf.append('<');
/* 135 */     if (!this.complete) {
/* 136 */       buf.append(this.namespacePrefix);
/*     */     }
/* 138 */     buf.append("Event logger=\"");
/* 139 */     String name = event.getLoggerName();
/* 140 */     if (name.isEmpty()) {
/* 141 */       name = "root";
/*     */     }
/* 143 */     buf.append(Transform.escapeHtmlTags(name));
/* 144 */     buf.append("\" timestamp=\"");
/* 145 */     buf.append(event.getTimeMillis());
/* 146 */     buf.append("\" level=\"");
/* 147 */     buf.append(Transform.escapeHtmlTags(getEventLevel(event)));
/* 148 */     buf.append("\" thread=\"");
/* 149 */     buf.append(Transform.escapeHtmlTags(event.getThreadName()));
/* 150 */     buf.append("\">");
/* 151 */     buf.append(this.eol);
/*     */     
/* 153 */     Message msg = event.getMessage();
/* 154 */     if (msg != null) {
/* 155 */       boolean xmlSupported = false;
/* 156 */       if (msg instanceof MultiformatMessage) {
/* 157 */         String[] formats = ((MultiformatMessage)msg).getFormats();
/* 158 */         for (String format : formats) {
/* 159 */           if (format.equalsIgnoreCase("XML")) {
/* 160 */             xmlSupported = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/* 165 */       buf.append(this.indent2);
/* 166 */       buf.append('<');
/* 167 */       if (!this.complete) {
/* 168 */         buf.append(this.namespacePrefix);
/*     */       }
/* 170 */       buf.append("Message>");
/* 171 */       if (xmlSupported) {
/* 172 */         buf.append(((MultiformatMessage)msg).getFormattedMessage(FORMATS));
/*     */       } else {
/* 174 */         buf.append("<![CDATA[");
/*     */ 
/*     */         
/* 177 */         Transform.appendEscapingCData(buf, event.getMessage().getFormattedMessage());
/* 178 */         buf.append("]]>");
/*     */       } 
/* 180 */       buf.append("</");
/* 181 */       if (!this.complete) {
/* 182 */         buf.append(this.namespacePrefix);
/*     */       }
/* 184 */       buf.append("Message>");
/* 185 */       buf.append(this.eol);
/*     */     } 
/*     */     
/* 188 */     if (event.getContextStack().getDepth() > 0) {
/* 189 */       buf.append(this.indent2);
/* 190 */       buf.append('<');
/* 191 */       if (!this.complete) {
/* 192 */         buf.append(this.namespacePrefix);
/*     */       }
/* 194 */       buf.append("NDC><![CDATA[");
/* 195 */       Transform.appendEscapingCData(buf, event.getContextStack().toString());
/* 196 */       buf.append("]]></");
/* 197 */       if (!this.complete) {
/* 198 */         buf.append(this.namespacePrefix);
/*     */       }
/* 200 */       buf.append("NDC>");
/* 201 */       buf.append(this.eol);
/*     */     } 
/*     */     
/* 204 */     Throwable throwable = event.getThrown();
/* 205 */     if (throwable != null) {
/* 206 */       List<String> s = Throwables.toStringList(throwable);
/* 207 */       buf.append(this.indent2);
/* 208 */       buf.append('<');
/* 209 */       if (!this.complete) {
/* 210 */         buf.append(this.namespacePrefix);
/*     */       }
/* 212 */       buf.append("Throwable><![CDATA[");
/* 213 */       for (String str : s) {
/* 214 */         Transform.appendEscapingCData(buf, str);
/* 215 */         buf.append(this.eol);
/*     */       } 
/* 217 */       buf.append("]]></");
/* 218 */       if (!this.complete) {
/* 219 */         buf.append(this.namespacePrefix);
/*     */       }
/* 221 */       buf.append("Throwable>");
/* 222 */       buf.append(this.eol);
/*     */     } 
/*     */     
/* 225 */     if (this.locationInfo) {
/* 226 */       StackTraceElement element = event.getSource();
/* 227 */       buf.append(this.indent2);
/* 228 */       buf.append('<');
/* 229 */       if (!this.complete) {
/* 230 */         buf.append(this.namespacePrefix);
/*     */       }
/* 232 */       buf.append("LocationInfo class=\"");
/* 233 */       buf.append(Transform.escapeHtmlTags(element.getClassName()));
/* 234 */       buf.append("\" method=\"");
/* 235 */       buf.append(Transform.escapeHtmlTags(element.getMethodName()));
/* 236 */       buf.append("\" file=\"");
/* 237 */       buf.append(Transform.escapeHtmlTags(element.getFileName()));
/* 238 */       buf.append("\" line=\"");
/* 239 */       buf.append(element.getLineNumber());
/* 240 */       buf.append("\"/>");
/* 241 */       buf.append(this.eol);
/*     */     } 
/*     */     
/* 244 */     if (this.properties && event.getContextMap().size() > 0) {
/* 245 */       buf.append(this.indent2);
/* 246 */       buf.append('<');
/* 247 */       if (!this.complete) {
/* 248 */         buf.append(this.namespacePrefix);
/*     */       }
/* 250 */       buf.append("Properties>");
/* 251 */       buf.append(this.eol);
/* 252 */       for (Map.Entry<String, String> entry : (Iterable<Map.Entry<String, String>>)event.getContextMap().entrySet()) {
/* 253 */         buf.append(this.indent3);
/* 254 */         buf.append('<');
/* 255 */         if (!this.complete) {
/* 256 */           buf.append(this.namespacePrefix);
/*     */         }
/* 258 */         buf.append("Data name=\"");
/* 259 */         buf.append(Transform.escapeHtmlTags(entry.getKey()));
/* 260 */         buf.append("\" value=\"");
/* 261 */         buf.append(Transform.escapeHtmlTags(String.valueOf(entry.getValue())));
/* 262 */         buf.append("\"/>");
/* 263 */         buf.append(this.eol);
/*     */       } 
/* 265 */       buf.append(this.indent2);
/* 266 */       buf.append("</");
/* 267 */       if (!this.complete) {
/* 268 */         buf.append(this.namespacePrefix);
/*     */       }
/* 270 */       buf.append("Properties>");
/* 271 */       buf.append(this.eol);
/*     */     } 
/*     */     
/* 274 */     buf.append(this.indent1);
/* 275 */     buf.append("</");
/* 276 */     if (!this.complete) {
/* 277 */       buf.append(this.namespacePrefix);
/*     */     }
/* 279 */     buf.append("Event>");
/* 280 */     buf.append(this.eol);
/*     */     
/* 282 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getHeader() {
/* 296 */     if (!this.complete) {
/* 297 */       return null;
/*     */     }
/* 299 */     StringBuilder buf = new StringBuilder();
/* 300 */     buf.append("<?xml version=\"1.0\" encoding=\"");
/* 301 */     buf.append(getCharset().name());
/* 302 */     buf.append("\"?>");
/* 303 */     buf.append(this.eol);
/*     */     
/* 305 */     buf.append('<');
/* 306 */     buf.append("Events");
/* 307 */     buf.append(" xmlns=\"http://logging.apache.org/log4j/2.0/events\">");
/* 308 */     buf.append(this.eol);
/* 309 */     return buf.toString().getBytes(getCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFooter() {
/* 320 */     if (!this.complete) {
/* 321 */       return null;
/*     */     }
/* 323 */     return ("</Events>" + this.eol).getBytes(getCharset());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getContentFormat() {
/* 335 */     Map<String, String> result = new HashMap<>();
/*     */     
/* 337 */     result.put("xsd", "log4j-events.xsd");
/* 338 */     result.put("version", "2.0");
/* 339 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContentType() {
/* 347 */     return "text/xml; charset=" + getCharset();
/*     */   }
/*     */   
/*     */   private static String getEventLevel(LogEvent event) {
/* 351 */     Marker marker = event.getMarker();
/* 352 */     if (marker != null && marker.isInstanceOf("FATAL")) {
/* 353 */       return String.valueOf(Level.FATAL);
/*     */     }
/* 355 */     return String.valueOf(event.getLevel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @PluginFactory
/*     */   public static LegacyXMLLayout createLayout(@PluginAttribute("locationInfo") boolean locationInfo, @PluginAttribute("properties") boolean properties, @PluginAttribute("complete") boolean completeStr, @PluginAttribute("compact") boolean compactStr, @PluginAttribute("namespacePrefix") String namespacePrefix, @PluginAttribute(value = "charset", defaultString = "UTF-8") Charset charset) {
/* 377 */     return new LegacyXMLLayout(locationInfo, properties, completeStr, compactStr, namespacePrefix, charset);
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\logging\1.0.0\logging-1.0.0.jar!\com\mojang\logging\plugins\LegacyXMLLayout.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */