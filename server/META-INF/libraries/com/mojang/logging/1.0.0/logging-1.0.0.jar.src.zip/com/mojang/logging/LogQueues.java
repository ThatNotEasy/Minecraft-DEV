/*    */ package com.mojang.logging;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.LinkedBlockingQueue;
/*    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ public class LogQueues {
/* 11 */   private static final Map<String, BlockingQueue<String>> QUEUES = new HashMap<>();
/* 12 */   private static final ReentrantReadWriteLock QUEUE_LOCK = new ReentrantReadWriteLock();
/*    */   
/*    */   public static BlockingQueue<String> getOrCreateQueue(String target) {
/*    */     try {
/* 16 */       QUEUE_LOCK.readLock().lock();
/* 17 */       BlockingQueue<String> queue = QUEUES.get(target);
/* 18 */       if (queue != null) {
/* 19 */         return queue;
/*    */       }
/*    */     } finally {
/* 22 */       QUEUE_LOCK.readLock().unlock();
/*    */     } 
/*    */     
/*    */     try {
/* 26 */       QUEUE_LOCK.writeLock().lock();
/* 27 */       return QUEUES.computeIfAbsent(target, k -> new LinkedBlockingQueue());
/*    */     } finally {
/* 29 */       QUEUE_LOCK.writeLock().unlock();
/*    */     } 
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public static String getNextLogEvent(String queueName) {
/* 35 */     QUEUE_LOCK.readLock().lock();
/* 36 */     BlockingQueue<String> queue = QUEUES.get(queueName);
/* 37 */     QUEUE_LOCK.readLock().unlock();
/*    */     
/* 39 */     if (queue != null) {
/*    */       try {
/* 41 */         return queue.take();
/* 42 */       } catch (InterruptedException interruptedException) {}
/*    */     }
/*    */ 
/*    */     
/* 46 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\logging\1.0.0\logging-1.0.0.jar!\com\mojang\logging\LogQueues.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */