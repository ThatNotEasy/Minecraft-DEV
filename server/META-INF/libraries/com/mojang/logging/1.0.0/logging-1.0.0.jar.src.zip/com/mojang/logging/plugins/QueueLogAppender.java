/*    */ package com.mojang.logging.plugins;
/*    */ 
/*    */ import com.mojang.logging.LogQueues;
/*    */ import java.io.Serializable;
/*    */ import java.util.Objects;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import org.apache.logging.log4j.core.Filter;
/*    */ import org.apache.logging.log4j.core.Layout;
/*    */ import org.apache.logging.log4j.core.LogEvent;
/*    */ import org.apache.logging.log4j.core.appender.AbstractAppender;
/*    */ import org.apache.logging.log4j.core.config.plugins.Plugin;
/*    */ import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
/*    */ import org.apache.logging.log4j.core.config.plugins.PluginElement;
/*    */ import org.apache.logging.log4j.core.config.plugins.PluginFactory;
/*    */ import org.apache.logging.log4j.core.layout.PatternLayout;
/*    */ 
/*    */ @Plugin(name = "Queue", category = "Core", elementType = "appender", printObject = true)
/*    */ public class QueueLogAppender
/*    */   extends AbstractAppender
/*    */ {
/*    */   private static final int MAX_CAPACITY = 250;
/*    */   private final BlockingQueue<String> queue;
/*    */   
/*    */   public QueueLogAppender(String name, Filter filter, Layout<? extends Serializable> layout, boolean ignoreExceptions, BlockingQueue<String> queue) {
/* 25 */     super(name, filter, layout, ignoreExceptions);
/* 26 */     this.queue = queue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void append(LogEvent event) {
/* 31 */     if (this.queue.size() >= 250) {
/* 32 */       this.queue.clear();
/*    */     }
/* 34 */     this.queue.add(getLayout().toSerializable(event).toString());
/*    */   }
/*    */   @PluginFactory
/*    */   public static QueueLogAppender createAppender(@PluginAttribute("name") String name, @PluginAttribute("ignoreExceptions") String ignore, @PluginElement("Layout") Layout<? extends Serializable> layout, @PluginElement("Filters") Filter filter, @PluginAttribute("target") String target) {
/*    */     PatternLayout patternLayout;
/* 39 */     boolean ignoreExceptions = Boolean.parseBoolean(ignore);
/*    */     
/* 41 */     if (name == null) {
/* 42 */       LOGGER.error("No name provided for QueueLogAppender");
/* 43 */       return null;
/*    */     } 
/*    */     
/* 46 */     BlockingQueue<String> queue = LogQueues.getOrCreateQueue(Objects.<String>requireNonNullElse(target, name));
/*    */     
/* 48 */     if (layout == null) {
/* 49 */       patternLayout = PatternLayout.newBuilder().build();
/*    */     }
/*    */     
/* 52 */     return new QueueLogAppender(name, filter, (Layout<? extends Serializable>)patternLayout, ignoreExceptions, queue);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\logging\1.0.0\logging-1.0.0.jar!\com\mojang\logging\plugins\QueueLogAppender.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */