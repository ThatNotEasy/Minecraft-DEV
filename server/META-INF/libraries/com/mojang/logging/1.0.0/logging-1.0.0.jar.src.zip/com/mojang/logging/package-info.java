package com.mojang.logging;

import com.mojang.logging.annotations.FieldsAreNonnullByDefault;
import com.mojang.logging.annotations.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;



/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\logging\1.0.0\logging-1.0.0.jar!\com\mojang\logging\package-info.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */