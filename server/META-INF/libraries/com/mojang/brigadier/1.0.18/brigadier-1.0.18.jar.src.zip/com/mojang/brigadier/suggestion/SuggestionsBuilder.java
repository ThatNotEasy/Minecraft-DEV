/*    */ package com.mojang.brigadier.suggestion;
/*    */ 
/*    */ import com.mojang.brigadier.Message;
/*    */ import com.mojang.brigadier.context.StringRange;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SuggestionsBuilder
/*    */ {
/*    */   private final String input;
/*    */   private final String inputLowerCase;
/*    */   private final int start;
/*    */   private final String remaining;
/*    */   private final String remainingLowerCase;
/* 20 */   private final List<Suggestion> result = new ArrayList<>();
/*    */   
/*    */   public SuggestionsBuilder(String input, String inputLowerCase, int start) {
/* 23 */     this.input = input;
/* 24 */     this.inputLowerCase = inputLowerCase;
/* 25 */     this.start = start;
/* 26 */     this.remaining = input.substring(start);
/* 27 */     this.remainingLowerCase = inputLowerCase.substring(start);
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder(String input, int start) {
/* 31 */     this(input, input.toLowerCase(Locale.ROOT), start);
/*    */   }
/*    */   
/*    */   public String getInput() {
/* 35 */     return this.input;
/*    */   }
/*    */   
/*    */   public int getStart() {
/* 39 */     return this.start;
/*    */   }
/*    */   
/*    */   public String getRemaining() {
/* 43 */     return this.remaining;
/*    */   }
/*    */   
/*    */   public String getRemainingLowerCase() {
/* 47 */     return this.remainingLowerCase;
/*    */   }
/*    */   
/*    */   public Suggestions build() {
/* 51 */     return Suggestions.create(this.input, this.result);
/*    */   }
/*    */   
/*    */   public CompletableFuture<Suggestions> buildFuture() {
/* 55 */     return CompletableFuture.completedFuture(build());
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder suggest(String text) {
/* 59 */     if (text.equals(this.remaining)) {
/* 60 */       return this;
/*    */     }
/* 62 */     this.result.add(new Suggestion(StringRange.between(this.start, this.input.length()), text));
/* 63 */     return this;
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder suggest(String text, Message tooltip) {
/* 67 */     if (text.equals(this.remaining)) {
/* 68 */       return this;
/*    */     }
/* 70 */     this.result.add(new Suggestion(StringRange.between(this.start, this.input.length()), text, tooltip));
/* 71 */     return this;
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder suggest(int value) {
/* 75 */     this.result.add(new IntegerSuggestion(StringRange.between(this.start, this.input.length()), value));
/* 76 */     return this;
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder suggest(int value, Message tooltip) {
/* 80 */     this.result.add(new IntegerSuggestion(StringRange.between(this.start, this.input.length()), value, tooltip));
/* 81 */     return this;
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder add(SuggestionsBuilder other) {
/* 85 */     this.result.addAll(other.result);
/* 86 */     return this;
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder createOffset(int start) {
/* 90 */     return new SuggestionsBuilder(this.input, this.inputLowerCase, start);
/*    */   }
/*    */   
/*    */   public SuggestionsBuilder restart() {
/* 94 */     return createOffset(this.start);
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\brigadier\1.0.18\brigadier-1.0.18.jar!\com\mojang\brigadier\suggestion\SuggestionsBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */