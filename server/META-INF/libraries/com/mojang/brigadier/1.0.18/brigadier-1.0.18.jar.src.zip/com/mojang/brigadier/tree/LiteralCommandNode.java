/*     */ package com.mojang.brigadier.tree;
/*     */ 
/*     */ import com.mojang.brigadier.Command;
/*     */ import com.mojang.brigadier.RedirectModifier;
/*     */ import com.mojang.brigadier.StringReader;
/*     */ import com.mojang.brigadier.builder.ArgumentBuilder;
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.context.CommandContextBuilder;
/*     */ import com.mojang.brigadier.context.StringRange;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import com.mojang.brigadier.suggestion.Suggestions;
/*     */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Predicate;
/*     */ 
/*     */ 
/*     */ public class LiteralCommandNode<S>
/*     */   extends CommandNode<S>
/*     */ {
/*     */   private final String literal;
/*     */   private final String literalLowerCase;
/*     */   
/*     */   public LiteralCommandNode(String literal, Command<S> command, Predicate<S> requirement, CommandNode<S> redirect, RedirectModifier<S> modifier, boolean forks) {
/*  28 */     super(command, requirement, redirect, modifier, forks);
/*  29 */     this.literal = literal;
/*  30 */     this.literalLowerCase = literal.toLowerCase(Locale.ROOT);
/*     */   }
/*     */   
/*     */   public String getLiteral() {
/*  34 */     return this.literal;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  39 */     return this.literal;
/*     */   }
/*     */ 
/*     */   
/*     */   public void parse(StringReader reader, CommandContextBuilder<S> contextBuilder) throws CommandSyntaxException {
/*  44 */     int start = reader.getCursor();
/*  45 */     int end = parse(reader);
/*  46 */     if (end > -1) {
/*  47 */       contextBuilder.withNode(this, StringRange.between(start, end));
/*     */       
/*     */       return;
/*     */     } 
/*  51 */     throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.literalIncorrect().createWithContext(reader, this.literal);
/*     */   }
/*     */   
/*     */   private int parse(StringReader reader) {
/*  55 */     int start = reader.getCursor();
/*  56 */     if (reader.canRead(this.literal.length())) {
/*  57 */       int end = start + this.literal.length();
/*  58 */       if (reader.getString().substring(start, end).equals(this.literal)) {
/*  59 */         reader.setCursor(end);
/*  60 */         if (!reader.canRead() || reader.peek() == ' ') {
/*  61 */           return end;
/*     */         }
/*  63 */         reader.setCursor(start);
/*     */       } 
/*     */     } 
/*     */     
/*  67 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
/*  72 */     if (this.literalLowerCase.startsWith(builder.getRemainingLowerCase())) {
/*  73 */       return builder.suggest(this.literal).buildFuture();
/*     */     }
/*  75 */     return Suggestions.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValidInput(String input) {
/*  81 */     return (parse(new StringReader(input)) > -1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  86 */     if (this == o) return true; 
/*  87 */     if (!(o instanceof LiteralCommandNode)) return false;
/*     */     
/*  89 */     LiteralCommandNode that = (LiteralCommandNode)o;
/*     */     
/*  91 */     if (!this.literal.equals(that.literal)) return false; 
/*  92 */     return super.equals(o);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getUsageText() {
/*  97 */     return this.literal;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 102 */     int result = this.literal.hashCode();
/* 103 */     result = 31 * result + super.hashCode();
/* 104 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public LiteralArgumentBuilder<S> createBuilder() {
/* 109 */     LiteralArgumentBuilder<S> builder = LiteralArgumentBuilder.literal(this.literal);
/* 110 */     builder.requires(getRequirement());
/* 111 */     builder.forward(getRedirect(), getRedirectModifier(), isFork());
/* 112 */     if (getCommand() != null) {
/* 113 */       builder.executes(getCommand());
/*     */     }
/* 115 */     return builder;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getSortedKey() {
/* 120 */     return this.literal;
/*     */   }
/*     */ 
/*     */   
/*     */   public Collection<String> getExamples() {
/* 125 */     return Collections.singleton(this.literal);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 130 */     return "<literal " + this.literal + ">";
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\brigadier\1.0.18\brigadier-1.0.18.jar!\com\mojang\brigadier\tree\LiteralCommandNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */