package com.mojang.brigadier;

import com.mojang.brigadier.tree.CommandNode;
import java.util.Collection;

@FunctionalInterface
public interface AmbiguityConsumer<S> {
  void ambiguous(CommandNode<S> paramCommandNode1, CommandNode<S> paramCommandNode2, CommandNode<S> paramCommandNode3, Collection<String> paramCollection);
}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\brigadier\1.0.18\brigadier-1.0.18.jar!\com\mojang\brigadier\AmbiguityConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */