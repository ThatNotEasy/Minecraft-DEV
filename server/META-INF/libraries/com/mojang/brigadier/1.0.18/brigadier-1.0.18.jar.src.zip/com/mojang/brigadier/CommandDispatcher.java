/*     */ package com.mojang.brigadier;
/*     */ 
/*     */ import com.mojang.brigadier.builder.LiteralArgumentBuilder;
/*     */ import com.mojang.brigadier.context.CommandContext;
/*     */ import com.mojang.brigadier.context.CommandContextBuilder;
/*     */ import com.mojang.brigadier.context.SuggestionContext;
/*     */ import com.mojang.brigadier.exceptions.CommandSyntaxException;
/*     */ import com.mojang.brigadier.suggestion.Suggestions;
/*     */ import com.mojang.brigadier.suggestion.SuggestionsBuilder;
/*     */ import com.mojang.brigadier.tree.CommandNode;
/*     */ import com.mojang.brigadier.tree.LiteralCommandNode;
/*     */ import com.mojang.brigadier.tree.RootCommandNode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandDispatcher<S>
/*     */ {
/*     */   public static final String ARGUMENT_SEPARATOR = " ";
/*     */   public static final char ARGUMENT_SEPARATOR_CHAR = ' ';
/*     */   private static final String USAGE_OPTIONAL_OPEN = "[";
/*     */   private static final String USAGE_OPTIONAL_CLOSE = "]";
/*     */   private static final String USAGE_REQUIRED_OPEN = "(";
/*     */   private static final String USAGE_REQUIRED_CLOSE = ")";
/*     */   private static final String USAGE_OR = "|";
/*     */   private final RootCommandNode<S> root;
/*     */   
/*  59 */   private final Predicate<CommandNode<S>> hasCommand = new Predicate<CommandNode<S>>()
/*     */     {
/*     */       public boolean test(CommandNode<S> input) {
/*  62 */         return (input != null && (input.getCommand() != null || input.getChildren().stream().anyMatch(CommandDispatcher.this.hasCommand)));
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResultConsumer<S> consumer = (c, s, r) -> {
/*     */     
/*     */     };
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandDispatcher(RootCommandNode<S> root) {
/*  76 */     this.root = root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandDispatcher() {
/*  83 */     this(new RootCommandNode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LiteralCommandNode<S> register(LiteralArgumentBuilder<S> command) {
/*  97 */     LiteralCommandNode<S> build = command.build();
/*  98 */     this.root.addChild((CommandNode)build);
/*  99 */     return build;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConsumer(ResultConsumer<S> consumer) {
/* 108 */     this.consumer = consumer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execute(String input, S source) throws CommandSyntaxException {
/* 142 */     return execute(new StringReader(input), source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execute(StringReader input, S source) throws CommandSyntaxException {
/* 176 */     ParseResults<S> parse = parse(input, source);
/* 177 */     return execute(parse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execute(ParseResults<S> parse) throws CommandSyntaxException {
/* 207 */     if (parse.getReader().canRead()) {
/* 208 */       if (parse.getExceptions().size() == 1)
/* 209 */         throw (CommandSyntaxException)parse.getExceptions().values().iterator().next(); 
/* 210 */       if (parse.getContext().getRange().isEmpty()) {
/* 211 */         throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherUnknownCommand().createWithContext(parse.getReader());
/*     */       }
/* 213 */       throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherUnknownArgument().createWithContext(parse.getReader());
/*     */     } 
/*     */ 
/*     */     
/* 217 */     int result = 0;
/* 218 */     int successfulForks = 0;
/* 219 */     boolean forked = false;
/* 220 */     boolean foundCommand = false;
/* 221 */     String command = parse.getReader().getString();
/* 222 */     CommandContext<S> original = parse.getContext().build(command);
/* 223 */     List<CommandContext<S>> contexts = Collections.singletonList(original);
/* 224 */     ArrayList<CommandContext<S>> next = null;
/*     */     
/* 226 */     while (contexts != null) {
/* 227 */       int size = contexts.size();
/* 228 */       for (int i = 0; i < size; i++) {
/* 229 */         CommandContext<S> context = contexts.get(i);
/* 230 */         CommandContext<S> child = context.getChild();
/* 231 */         if (child != null) {
/* 232 */           forked |= context.isForked();
/* 233 */           if (child.hasNodes()) {
/* 234 */             foundCommand = true;
/* 235 */             RedirectModifier<S> modifier = context.getRedirectModifier();
/* 236 */             if (modifier == null) {
/* 237 */               if (next == null) {
/* 238 */                 next = new ArrayList<>(1);
/*     */               }
/* 240 */               next.add(child.copyFor(context.getSource()));
/*     */             } else {
/*     */               try {
/* 243 */                 Collection<S> results = modifier.apply(context);
/* 244 */                 if (!results.isEmpty()) {
/* 245 */                   if (next == null) {
/* 246 */                     next = new ArrayList<>(results.size());
/*     */                   }
/* 248 */                   for (S source : results) {
/* 249 */                     next.add(child.copyFor(source));
/*     */                   }
/*     */                 } 
/* 252 */               } catch (CommandSyntaxException ex) {
/* 253 */                 this.consumer.onCommandComplete(context, false, 0);
/* 254 */                 if (!forked) {
/* 255 */                   throw ex;
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/* 260 */         } else if (context.getCommand() != null) {
/* 261 */           foundCommand = true;
/*     */           try {
/* 263 */             int value = context.getCommand().run(context);
/* 264 */             result += value;
/* 265 */             this.consumer.onCommandComplete(context, true, value);
/* 266 */             successfulForks++;
/* 267 */           } catch (CommandSyntaxException ex) {
/* 268 */             this.consumer.onCommandComplete(context, false, 0);
/* 269 */             if (!forked) {
/* 270 */               throw ex;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 276 */       contexts = next;
/* 277 */       next = null;
/*     */     } 
/*     */     
/* 280 */     if (!foundCommand) {
/* 281 */       this.consumer.onCommandComplete(original, false, 0);
/* 282 */       throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherUnknownCommand().createWithContext(parse.getReader());
/*     */     } 
/*     */     
/* 285 */     return forked ? successfulForks : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseResults<S> parse(String command, S source) {
/* 316 */     return parse(new StringReader(command), source);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ParseResults<S> parse(StringReader command, S source) {
/* 347 */     CommandContextBuilder<S> context = new CommandContextBuilder(this, source, (CommandNode)this.root, command.getCursor());
/* 348 */     return parseNodes((CommandNode<S>)this.root, command, context);
/*     */   }
/*     */   
/*     */   private ParseResults<S> parseNodes(CommandNode<S> node, StringReader originalReader, CommandContextBuilder<S> contextSoFar) {
/* 352 */     S source = (S)contextSoFar.getSource();
/* 353 */     Map<CommandNode<S>, CommandSyntaxException> errors = null;
/* 354 */     List<ParseResults<S>> potentials = null;
/* 355 */     int cursor = originalReader.getCursor();
/*     */     
/* 357 */     for (CommandNode<S> child : (Iterable<CommandNode<S>>)node.getRelevantNodes(originalReader)) {
/* 358 */       if (!child.canUse(source)) {
/*     */         continue;
/*     */       }
/* 361 */       CommandContextBuilder<S> context = contextSoFar.copy();
/* 362 */       StringReader reader = new StringReader(originalReader);
/*     */       try {
/*     */         try {
/* 365 */           child.parse(reader, context);
/* 366 */         } catch (RuntimeException ex) {
/* 367 */           throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherParseException().createWithContext(reader, ex.getMessage());
/*     */         } 
/* 369 */         if (reader.canRead() && 
/* 370 */           reader.peek() != ' ') {
/* 371 */           throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.dispatcherExpectedArgumentSeparator().createWithContext(reader);
/*     */         }
/*     */       }
/* 374 */       catch (CommandSyntaxException ex) {
/* 375 */         if (errors == null) {
/* 376 */           errors = new LinkedHashMap<>();
/*     */         }
/* 378 */         errors.put(child, ex);
/* 379 */         reader.setCursor(cursor);
/*     */         
/*     */         continue;
/*     */       } 
/* 383 */       context.withCommand(child.getCommand());
/* 384 */       if (reader.canRead((child.getRedirect() == null) ? 2 : 1)) {
/* 385 */         reader.skip();
/* 386 */         if (child.getRedirect() != null) {
/* 387 */           CommandContextBuilder<S> childContext = new CommandContextBuilder(this, source, child.getRedirect(), reader.getCursor());
/* 388 */           ParseResults<S> parseResults = parseNodes(child.getRedirect(), reader, childContext);
/* 389 */           context.withChild(parseResults.getContext());
/* 390 */           return new ParseResults<>(context, parseResults.getReader(), parseResults.getExceptions());
/*     */         } 
/* 392 */         ParseResults<S> parse = parseNodes(child, reader, context);
/* 393 */         if (potentials == null) {
/* 394 */           potentials = new ArrayList<>(1);
/*     */         }
/* 396 */         potentials.add(parse);
/*     */         continue;
/*     */       } 
/* 399 */       if (potentials == null) {
/* 400 */         potentials = new ArrayList<>(1);
/*     */       }
/* 402 */       potentials.add(new ParseResults<>(context, reader, Collections.emptyMap()));
/*     */     } 
/*     */ 
/*     */     
/* 406 */     if (potentials != null) {
/* 407 */       if (potentials.size() > 1) {
/* 408 */         potentials.sort((a, b) -> 
/* 409 */             (!a.getReader().canRead() && b.getReader().canRead()) ? -1 : (
/*     */ 
/*     */             
/* 412 */             (a.getReader().canRead() && !b.getReader().canRead()) ? 1 : (
/*     */ 
/*     */             
/* 415 */             (a.getExceptions().isEmpty() && !b.getExceptions().isEmpty()) ? -1 : (
/*     */ 
/*     */             
/* 418 */             (!a.getExceptions().isEmpty() && b.getExceptions().isEmpty()) ? 1 : 0))));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 424 */       return potentials.get(0);
/*     */     } 
/*     */     
/* 427 */     return new ParseResults<>(contextSoFar, originalReader, (errors == null) ? Collections.<CommandNode<S>, CommandSyntaxException>emptyMap() : errors);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAllUsage(CommandNode<S> node, S source, boolean restricted) {
/* 452 */     ArrayList<String> result = new ArrayList<>();
/* 453 */     getAllUsage(node, source, result, "", restricted);
/* 454 */     return result.<String>toArray(new String[result.size()]);
/*     */   }
/*     */   
/*     */   private void getAllUsage(CommandNode<S> node, S source, ArrayList<String> result, String prefix, boolean restricted) {
/* 458 */     if (restricted && !node.canUse(source)) {
/*     */       return;
/*     */     }
/*     */     
/* 462 */     if (node.getCommand() != null) {
/* 463 */       result.add(prefix);
/*     */     }
/*     */     
/* 466 */     if (node.getRedirect() != null) {
/* 467 */       String redirect = (node.getRedirect() == this.root) ? "..." : ("-> " + node.getRedirect().getUsageText());
/* 468 */       result.add(prefix.isEmpty() ? (node.getUsageText() + " " + redirect) : (prefix + " " + redirect));
/* 469 */     } else if (!node.getChildren().isEmpty()) {
/* 470 */       for (CommandNode<S> child : (Iterable<CommandNode<S>>)node.getChildren()) {
/* 471 */         getAllUsage(child, source, result, prefix.isEmpty() ? child.getUsageText() : (prefix + " " + child.getUsageText()), restricted);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<CommandNode<S>, String> getSmartUsage(CommandNode<S> node, S source) {
/* 498 */     Map<CommandNode<S>, String> result = new LinkedHashMap<>();
/*     */     
/* 500 */     boolean optional = (node.getCommand() != null);
/* 501 */     for (CommandNode<S> child : (Iterable<CommandNode<S>>)node.getChildren()) {
/* 502 */       String usage = getSmartUsage(child, source, optional, false);
/* 503 */       if (usage != null) {
/* 504 */         result.put(child, usage);
/*     */       }
/*     */     } 
/* 507 */     return result;
/*     */   }
/*     */   
/*     */   private String getSmartUsage(CommandNode<S> node, S source, boolean optional, boolean deep) {
/* 511 */     if (!node.canUse(source)) {
/* 512 */       return null;
/*     */     }
/*     */     
/* 515 */     String self = optional ? ("[" + node.getUsageText() + "]") : node.getUsageText();
/* 516 */     boolean childOptional = (node.getCommand() != null);
/* 517 */     String open = childOptional ? "[" : "(";
/* 518 */     String close = childOptional ? "]" : ")";
/*     */     
/* 520 */     if (!deep) {
/* 521 */       if (node.getRedirect() != null) {
/* 522 */         String redirect = (node.getRedirect() == this.root) ? "..." : ("-> " + node.getRedirect().getUsageText());
/* 523 */         return self + " " + redirect;
/*     */       } 
/* 525 */       Collection<CommandNode<S>> children = (Collection<CommandNode<S>>)node.getChildren().stream().filter(c -> c.canUse(source)).collect(Collectors.toList());
/* 526 */       if (children.size() == 1) {
/* 527 */         String usage = getSmartUsage(children.iterator().next(), source, childOptional, childOptional);
/* 528 */         if (usage != null) {
/* 529 */           return self + " " + usage;
/*     */         }
/* 531 */       } else if (children.size() > 1) {
/* 532 */         Set<String> childUsage = new LinkedHashSet<>();
/* 533 */         for (CommandNode<S> child : children) {
/* 534 */           String usage = getSmartUsage(child, source, childOptional, true);
/* 535 */           if (usage != null) {
/* 536 */             childUsage.add(usage);
/*     */           }
/*     */         } 
/* 539 */         if (childUsage.size() == 1) {
/* 540 */           String usage = childUsage.iterator().next();
/* 541 */           return self + " " + (childOptional ? ("[" + usage + "]") : usage);
/* 542 */         }  if (childUsage.size() > 1) {
/* 543 */           StringBuilder builder = new StringBuilder(open);
/* 544 */           int count = 0;
/* 545 */           for (CommandNode<S> child : children) {
/* 546 */             if (count > 0) {
/* 547 */               builder.append("|");
/*     */             }
/* 549 */             builder.append(child.getUsageText());
/* 550 */             count++;
/*     */           } 
/* 552 */           if (count > 0) {
/* 553 */             builder.append(close);
/* 554 */             return self + " " + builder.toString();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 561 */     return self;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompletableFuture<Suggestions> getCompletionSuggestions(ParseResults<S> parse) {
/* 580 */     return getCompletionSuggestions(parse, parse.getReader().getTotalLength());
/*     */   }
/*     */   
/*     */   public CompletableFuture<Suggestions> getCompletionSuggestions(ParseResults<S> parse, int cursor) {
/* 584 */     CommandContextBuilder<S> context = parse.getContext();
/*     */     
/* 586 */     SuggestionContext<S> nodeBeforeCursor = context.findSuggestionContext(cursor);
/* 587 */     CommandNode<S> parent = nodeBeforeCursor.parent;
/* 588 */     int start = Math.min(nodeBeforeCursor.startPos, cursor);
/*     */     
/* 590 */     String fullInput = parse.getReader().getString();
/* 591 */     String truncatedInput = fullInput.substring(0, cursor);
/* 592 */     String truncatedInputLowerCase = truncatedInput.toLowerCase(Locale.ROOT);
/* 593 */     CompletableFuture[] arrayOfCompletableFuture = new CompletableFuture[parent.getChildren().size()];
/* 594 */     int i = 0;
/* 595 */     for (CommandNode<S> node : (Iterable<CommandNode<S>>)parent.getChildren()) {
/* 596 */       CompletableFuture<Suggestions> future = Suggestions.empty();
/*     */       try {
/* 598 */         future = node.listSuggestions(context.build(truncatedInput), new SuggestionsBuilder(truncatedInput, truncatedInputLowerCase, start));
/* 599 */       } catch (CommandSyntaxException commandSyntaxException) {}
/*     */       
/* 601 */       arrayOfCompletableFuture[i++] = future;
/*     */     } 
/*     */     
/* 604 */     CompletableFuture<Suggestions> result = new CompletableFuture<>();
/* 605 */     CompletableFuture.allOf((CompletableFuture<?>[])arrayOfCompletableFuture).thenRun(() -> {
/*     */           List<Suggestions> suggestions = new ArrayList<>();
/*     */           
/*     */           for (CompletableFuture<Suggestions> future : futures) {
/*     */             suggestions.add(future.join());
/*     */           }
/*     */           result.complete(Suggestions.merge(fullInput, suggestions));
/*     */         });
/* 613 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RootCommandNode<S> getRoot() {
/* 626 */     return this.root;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection<String> getPath(CommandNode<S> target) {
/* 644 */     List<List<CommandNode<S>>> nodes = new ArrayList<>();
/* 645 */     addPaths((CommandNode<S>)this.root, nodes, new ArrayList<>());
/*     */     
/* 647 */     for (List<CommandNode<S>> list : nodes) {
/* 648 */       if (list.get(list.size() - 1) == target) {
/* 649 */         List<String> result = new ArrayList<>(list.size());
/* 650 */         for (CommandNode<S> node : list) {
/* 651 */           if (node != this.root) {
/* 652 */             result.add(node.getName());
/*     */           }
/*     */         } 
/* 655 */         return result;
/*     */       } 
/*     */     } 
/*     */     
/* 659 */     return Collections.emptyList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandNode<S> findNode(Collection<String> path) {
/*     */     CommandNode<S> commandNode;
/* 674 */     RootCommandNode<S> rootCommandNode = this.root;
/* 675 */     for (String name : path) {
/* 676 */       commandNode = rootCommandNode.getChild(name);
/* 677 */       if (commandNode == null) {
/* 678 */         return null;
/*     */       }
/*     */     } 
/* 681 */     return commandNode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void findAmbiguities(AmbiguityConsumer<S> consumer) {
/* 695 */     this.root.findAmbiguities(consumer);
/*     */   }
/*     */   
/*     */   private void addPaths(CommandNode<S> node, List<List<CommandNode<S>>> result, List<CommandNode<S>> parents) {
/* 699 */     List<CommandNode<S>> current = new ArrayList<>(parents);
/* 700 */     current.add(node);
/* 701 */     result.add(current);
/*     */     
/* 703 */     for (CommandNode<S> child : (Iterable<CommandNode<S>>)node.getChildren())
/* 704 */       addPaths(child, result, current); 
/*     */   }
/*     */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\brigadier\1.0.18\brigadier-1.0.18.jar!\com\mojang\brigadier\CommandDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */