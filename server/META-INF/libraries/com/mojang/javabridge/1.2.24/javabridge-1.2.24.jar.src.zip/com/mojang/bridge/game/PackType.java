/*   */ package com.mojang.bridge.game;
/*   */ 
/*   */ public enum PackType {
/* 4 */   RESOURCE,
/* 5 */   DATA;
/*   */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\javabridge\1.2.24\javabridge-1.2.24.jar!\com\mojang\bridge\game\PackType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */