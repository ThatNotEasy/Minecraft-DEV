package com.mojang.bridge.launcher;

import com.mojang.bridge.game.RunningGame;

public interface Launcher {
  void registerGame(RunningGame paramRunningGame);
}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\javabridge\1.2.24\javabridge-1.2.24.jar!\com\mojang\bridge\launcher\Launcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */