package com.mojang.bridge.launcher;

public interface LauncherProvider {
  Launcher createLauncher();
}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\javabridge\1.2.24\javabridge-1.2.24.jar!\com\mojang\bridge\launcher\LauncherProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */