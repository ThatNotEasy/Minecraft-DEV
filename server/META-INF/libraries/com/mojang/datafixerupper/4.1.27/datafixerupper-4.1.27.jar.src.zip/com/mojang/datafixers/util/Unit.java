/*    */ package com.mojang.datafixers.util;
/*    */ 
/*    */ 
/*    */ public enum Unit
/*    */ {
/*  6 */   INSTANCE;
/*    */ 
/*    */   
/*    */   public String toString() {
/* 10 */     return "Unit";
/*    */   }
/*    */ }


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\datafixerupper\4.1.27\datafixerupper-4.1.27.jar!\com\mojang\datafixer\\util\Unit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */