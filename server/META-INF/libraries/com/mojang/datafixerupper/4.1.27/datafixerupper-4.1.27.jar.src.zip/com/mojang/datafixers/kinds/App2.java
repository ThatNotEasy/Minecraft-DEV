package com.mojang.datafixers.kinds;

public interface App2<F extends K2, A, B> {}


/* Location:              C:\Users\apido\Desktop\MineCraft-Dev\server.jar!\META-INF\libraries\com\mojang\datafixerupper\4.1.27\datafixerupper-4.1.27.jar!\com\mojang\datafixers\kinds\App2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */